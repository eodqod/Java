package 첫째날;

import java.util.Scanner;

public class 스캐너 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = 1;
		while(n!=0) {
			System.out.print("0~255사이의 정수입력(0은 종료)");
			n = sc.nextInt();
			if(n==0) continue;

			System.out.println(Integer.toBinaryString(n)); //자바로 2진수 출력
			//프로그램으로 2진수 출력
			int mask = 0x80;  //8비트 중에서 최상위 1비트만 1인 이진수 : 1000 0000 
			for(int i=0; i<8; i++) {
				//삼항연산자 : 연산 대상이 3개인 연산자.
				//조건 ? 참인 경우 값 : 거짓인 경우 값
				System.out.print((mask&n) == mask ? "1" : "0");
				mask >>= 1;
			}
			System.out.println();
		}
		sc.close();
	}

}
