package 첫째날;

public class 색 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int color = 0xaabbccdd;
		
		int alpha = color >>> 24;
		System.out.println("ALPHA : " + Integer.toHexString(alpha));
		
		//0으로 AND연산을 하면 지워지고, 1로 AND연산을 하면 통과
		int red = color >>> 16 & 0xff;
		System.out.println("RED : " + Integer.toHexString(red));

		int green= color >>> 8 & 0xff;
		System.out.println("GREEN : " + Integer.toHexString(green));

		int blue= color & 0xff;
		System.out.println("BLUE : " + Integer.toHexString(blue));
		
		//색상 결합
		//0으로 OR연산을 하면 통과, 1로 OR연산을 하면 설정
		int color2 = 0;
		color2 = color2 | alpha << 24;
		System.out.println("color2 : " + Integer.toHexString(color2));

		color2 = color2 | red << 16;
		System.out.println("color2" + Integer.toHexString(color2));

		color2 = color2 | green << 8;
		System.out.println("color2 : " + Integer.toHexString(color2));

		color2 = color2 | blue;
		System.out.println("color2 : " + Integer.toHexString(color2));
		
		//red만 지우고 싶다
		color2 = color2 & 0xff00ffff;
		System.out.println("color2 : " + Integer.toHexString(color2));
		//red값을 72로 바꾸자
		color2 = color2 | 0x00720000;
		System.out.println("color2 : " + Integer.toHexString(color2));
	}

}
