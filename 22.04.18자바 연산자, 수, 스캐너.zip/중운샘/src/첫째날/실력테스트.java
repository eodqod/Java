package 첫째날;

public class 실력테스트 {
	public static void main(String[] args) {
		int birth = 940905;
		//**년 **월 **일 로 출력
		System.out.print(birth/10000 + "년 ");
		System.out.print(birth/100%100 + "월 ");
		System.out.println(birth%100 + "일 ");
		
		
		System.out.println(getTotalPage(0, 1));
		System.out.println(getTotalPage(1, 1));
		System.out.println(getTotalPage(2, 1));
		System.out.println(getTotalPage(1, 10));
		System.out.println(getTotalPage(10, 10));
		System.out.println(getTotalPage(11, 10));
	}
	public static int getTotalPage(int m, int n) {
		return (m-1)/n + 1;
//		int result = 0;
//		if(m%n==0) {  // 배수일 경우는 몫에 +1을 해주지 않는다.
//			result = m/n;
//		}else {
//			result = m/n + 1;  // 배수가 아니면 몫에 +1을 해줘야 한다.
//			return result;
//		}
		
		
		
		
		
	}
	

}
