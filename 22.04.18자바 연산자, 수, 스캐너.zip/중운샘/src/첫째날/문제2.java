package 첫째날;

import java.util.Scanner;

public class 문제2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//숫자 뒤집기
		//123==>321
		//1001==>1001
		//12345==>54321

		Scanner sc = new Scanner(System.in);
		int n = 1, len, temp;
		while(n!=0) {
			System.out.print("정수 입력 : ");
			n = sc.nextInt();
			if(n==0) continue;
			len = 1;
			temp = n;
			while(temp>=10) { // 1자리 버릴때마다 10을 곱해 자릿수를 구한다.
				len *= 10;    // 1자리 늘리기
				temp /= 10;   // 1자리 줄이기
			}
			System.out.println("자릿수 : " + len);
			int rev = 0;			    // 뒤집은 수
			temp = n;   			    // n값을 유지하기 위하여 임시변수에 넣기
			while(temp>0) {  		    //끝까지 반복
				rev += temp%10 * len;   //맨 뒷자리 잘라내서 1000, 100, 10, 1순서로 곱해서 더하기
				temp /= 10;  			// 맨 뒷자리 버리기
				len /= 10;  			// 곱하는값 자릿수 줄이기
			}
			System.out.println(n + " : " + rev);
		}
		sc.close();
	}	
	

}
