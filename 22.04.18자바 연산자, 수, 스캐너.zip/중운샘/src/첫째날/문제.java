package 첫째날;

public class 문제 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 10, y = 20;
		//두개의 숫자를 교환하여 출력하시오 단, 다른 변수를 사용하면 안된다.
		System.out.println(x + ", " + y);
		x = x + y; // x = 10 + 20 = 30
		y = x - y; // y = 30 - 20 = 10
		x = x - y; // x = 30 - 10 = 20
		System.out.println(x + ", " + y);
		//^(XOR) 비트 연산자 : 두개 값이 다를때만 참(1)이 되는 연산자.
		x = x ^ y;
		y = x ^ y;
		x = x ^ y;
		System.out.println(x + ", " + y);
		
		// 비트 와이즈 연산자 : ~(not), |(or), &(and), ^(xor)
		// AND 연산은 지울때 사용
		// OR 연산은 설정할때 사용
		// Shift 연산자 : <<, >>, >>>
		
		x = 1;						//0001
		x <<= 1;					//0010
		System.out.println(x);
		x <<= 2;					//1000
		System.out.println(x);
		x <<= 2;					//10 0000
		System.out.println(x);
		// x << n : x * 2의 n승
		
		x = x >> 1;
		System.out.println(x);		//1 0000
		// x >> n : x / 2의 n승
		
		x = 8;
		x >>= 1;
		System.out.println(x);
		
		x = 8;
		x >>>= 1;
		System.out.println(x);
		
		System.out.println("-".repeat(80));
		
		x = -8;
		x >>= 1;
		System.out.println(x);
		
		x = -8;
		x >>>= 1;
		System.out.println(x);
		
		
		
	}

}
