package 첫째날;

public class 수 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 0b10; //0b로 시작하면 2진수
		int b = 010;  //0으로 시작하면 8진수
		int c = 10;   //1~9로 시작하면 10진수
		int d = 0x10; //0x로 시작하면 16진수
		int e = 10_00_00_00_00; 
		
		System.out.println("A = " + a);
		System.out.println("B = " + b);
		System.out.println("C = " + c);
		System.out.println("D = " + d);
		System.out.println("E = " + e);
	}

}
