package 첫째날;

public class 증감연산자 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=10, j =10;
		int k = i+j;
		System.out.println(i + ", " + j + ", " + k); // 10, 10, 20
		
		++i;
		++j;

		k = i+j;
		System.out.println(i + ", " + j + ", " + k); // 11, 11, 22

		i++;
		j++;

		k = i+j;
		System.out.println(i + ", " + j + ", " + k); // 12, 12, 24
		
		//단독 실행시는 앞이나 뒤나 상관없다.
		
		//다른 연산자와 같이 사용할 경우에는 전위연산이 제일 우선순위가 높고 후위연산이 제일 늦다.
		
		k = ++i + j++; //++i;, k = i+j, j++;
		System.out.println(i + ", " + j + ", " + k); // 13, 13, 25
		
		k= i++ + ++j; // ++j;, k = i+j, i++;
		System.out.println(i + ", " + j + ", " + k); // 14, 14, 27
		
		k = i != j ? ++i : j++; //조건이 거짓이기 때문에 ++i는 실행되지 않는다.
		System.out.println(i + ", " + j + ", " + k); // 14, 15, 14
		
		// ||(OR) 연산의 경우 앞의 식이 참이면 뒤의 식은 계산하지 않는다.
		k = i!=j || ++i==j++ ? i : j;
		System.out.println(i + ", " + j + ", " + k); // 14, 15, 14

		// ||(OR) 연산의 경우 앞의 식이 거짓이면 뒤의 식은 계산하지 않는다.
		k = i!=j && ++i==j++ ? i : j;
		System.out.println(i + ", " + j + ", " + k); // 15, 16, 15
		
	}

}
