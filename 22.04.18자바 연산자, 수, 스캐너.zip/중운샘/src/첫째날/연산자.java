package 첫째날;

public class 연산자 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 100;
		System.out.println("a = " + a);
		System.out.println("a = " + Integer.toBinaryString(a));
		int b = ~a;  // 1의 보수를 구한다.
		System.out.println("a = " + b);
		System.out.println("a = " + Integer.toBinaryString(b));
		
		//컴퓨터는 덧셈만 하는 계산기이다. 뺄셈을 시키면 2의보수를 더해서 계산을 한다.
		int x = 10, y = 7;
		System.out.println(x + " - " + y + " = " + (x - y));
		System.out.println(x + " - " + y + " = " + (x + (~y + 1)));
		
		//1의 보수 + 1 = 2의 보수
		
		
	}

}
