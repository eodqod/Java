package kr.human.net1;

import lombok.Data;

@Data
public class DicVO {
	private String d;
	private String h;
	private String m;
	private String m1;
	private String m2;
	private String m3;
	private String m4;
	private String m5;
	private String r;
	private String ld;
}
