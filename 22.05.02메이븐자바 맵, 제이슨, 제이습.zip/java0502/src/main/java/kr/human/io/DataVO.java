package kr.human.io;

import java.io.Serializable;

public class DataVO implements Serializable{
	//자바는 클래스 내용이 변할때마다 새로운 시리얼버전아이디를 부여한다.
	//serialVersionUID가 다르면 다른객체로 인식한다.
	//수정 전의 데이터를 읽지 못하는 사태가 발생한다.
	//이것을 방지하기 위해서는 자동으로 serialVersionUID를 만들어서
	//serialVersionUID를 고정시켜 놓으면 된다.
	private static final long serialVersionUID = 6629188902613864727L;
	private String stringData;
	private int intData;
	
	//생성자
	public DataVO(String stringData, int intData) {
		super();
		this.stringData = stringData;
		this.intData = intData;
	}
	
	//겟터셋터
	public String getStringData() {
		return stringData;
	}
	public void setStringData(String stringData) {
		this.stringData = stringData;
	}
	public int getIntData() {
		return intData;
	}
	public void setIntData(int intData) {
		this.intData = intData;
	}

	//ToString
	@Override
	public String toString() {
		return "DataVO [stringData=" + stringData + ", intData=" + intData + "]";
	}
	
}
