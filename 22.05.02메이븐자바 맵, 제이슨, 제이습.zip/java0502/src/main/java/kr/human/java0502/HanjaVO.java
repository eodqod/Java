package kr.human.java0502;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class HanjaVO {
	private int index;
	private String h;
	private String k;
	private String m;
}
