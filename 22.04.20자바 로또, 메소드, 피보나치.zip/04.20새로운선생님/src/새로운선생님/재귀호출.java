package 새로운선생님;
//재귀호출 메소드 : 자신이 자신을 호출하는 메소드
//					잘쓰면 약, 잘못쓰면 독
public class 재귀호출 {

	public static void main(String[] args) {
		

	}

}
