package 새로운선생님;

public class 메소드3 {

	public static void main(String[] args) {
		int n = (int)(Math.random()*100); // 0~99사이의 난수를 발생시킨다.
		System.out.println(n + "은" + (isEven1(n) ? "짝":"홀") + "수입니다.");
		System.out.println(n + "은" + (isEven2(n) ? "짝":"홀") + "수입니다.");
		System.out.println(n + "은" + (isEven3(n) ? "짝":"홀") + "수입니다.");
		System.out.println("5! = " + multip(5));
		System.out.println("15! = " + multip(15));
		System.out.println("5! = " + factorial(5));
		System.out.println("15! = " + factorial(15));
	
		for(int i=1; i<=10; i++) System.out.printf("%5d", fibo1(i));
		System.out.println();

	}
	//문제 n!을 구하는 메소드를 만드시오
	//	  5! = 5*4*3*2*1

	public static long multip(int j) { 
		long result = 1;
		for(int i=j; i>=1; i--) {
			result *= i;
		}
		return result; 
	}
	//선생님풀이
	public static long factorial(int n) {
		long result = 1;
		while(n>0) result *= n--;
		return result;
	}
	
	//문제 n번째 피보나치 수열의 값을 구하는 메소드를 만드시오
	//피보나치 수열의 시작값은 1부터이다.
	public static int fibo1(int n) {
		int first = 0, second = 1;
		while(n>0) {
			second = first + second;
			first = second - first;
			n--;
		}
		return first;
	}
	
	
	//리턴은 여러번 나와도 되지만 한번만 나오게 작성하는 것이 좋다.
	public static boolean isEven1(int n) {
		if(n%2==0) {
			return true;
		}else {
			return false;
		}
	}
	
	public static boolean isEven2(int n) {
		boolean result = false;
		if(n%2==0) result = true;
		return result;
	}
	
	public static boolean isEven3(int n) {
		return n%2==0;
	}

	
}
