package 새로운선생님;

import java.util.Arrays;
import java.util.Random;

public class 로또2 {

	public static void main(String[] args) {
		int[] lotto = new int[6];
		Random random = new Random();
		
		System.out.println(lotto.length+"개 : "+Arrays.toString(lotto));

		for(int i=0; i<lotto.length; i++) {   // 6개 번호 필요
			lotto[i] = random.nextInt(45)+1;  // 1~45사이의 난수
			for(int j=0; j<i; j++) {		  // 이전에 발생한 번호만큼 반복
				if(lotto[i]==lotto[j])
					--i;
					break;
			}
		}
		System.out.println(lotto.length+"개 : "+Arrays.toString(lotto));
		Arrays.sort(lotto); // 오름차순 정렬
		System.out.println(lotto.length+"개 : "+Arrays.toString(lotto));
	}

}
