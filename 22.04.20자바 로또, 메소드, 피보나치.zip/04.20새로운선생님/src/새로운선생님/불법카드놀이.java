package 새로운선생님;

import java.util.Random;

public class 불법카드놀이 {

	public static void main(String[] args) {
		// lotto를 만드는 방법으로 카드 섞기
		int[] cards = new int[52];
		print(cards);
		
		Random rnd = new Random();
		int t;
		for(int i=0; i<cards.length; i++) {
			do {
				t = rnd.nextInt(cards.length);
			}while(cards[t] != 0);
			cards[t] = i;
		}
		print(cards);
		
		String[] kind = "◆♠♥♣".split("");
		String[] num = "1,2,3,4,5,6,7,8,9,10,J,Q,K".split(",");
		
		for(int i=0; i<cards.length; i++) {
			//0~51사이의 수를 /13하면 몫은 0~3까지이다. 몫이 무늬
			//0~51사이의 수를 %13하면 나머지는 0~12까지이다. 나머지가 숫자
			System.out.printf("%s%s ", kind[cards[i]/13], num[cards[i]%13]);
			if((i+1)%13==0) System.out.println();
		}
		
	}
	
	private static void print(int[] ar) {
		for(int i=0; i<ar.length; i++) {
			System.out.printf("%3d", ar[i]);
			if((i+1)%13==0) System.out.println();
		}
		System.out.println("-".repeat(40));
	}

}
