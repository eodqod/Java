package 새로운선생님;

import java.util.Scanner;

public class 피보나치수열 {

	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		Scanner sc = new Scanner(System.in);
//		System.out.println("양의 정수 입력 : ");
//		int n = sc.nextInt();  // 1번
//		int f = 0, s = 1, temp;  // 2번
//		while(f<n) {
//			System.out.printf("%5d", f);  // 3번
//			temp = s;   // 4번
//			s = f + s;  // 5번
//			f = temp;   // 6번
//		}  // 7번
		//임시변수 사용 안하고 풀이
		Scanner sc = new Scanner(System.in);
		System.out.println("양의 정수 입력 : ");
		int n = sc.nextInt();  // 1번
		int f = 0, s = 1;  // 2번
		while(f<n) {
			System.out.printf("%5d", f);  // 3번
			s = f + s;  // 5번
			f = s - f;   // 6번
		}  // 7번
		sc.close();
	}
}
