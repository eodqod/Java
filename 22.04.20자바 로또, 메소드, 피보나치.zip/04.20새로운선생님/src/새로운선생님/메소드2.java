package 새로운선생님;

public class 메소드2 {

	public static void main(String[] args) {
		int sum1 = 1+2+3+4+5 + 1+2+3+4 + 1+2+3+4+5+6+7+8+9+10;
		System.out.println("sum = " + sum1);
		
		int sum2 = sum(5) + sum(4) + sum(10);
		System.out.println("sum = " + sum2);
		
		int sum3 = 1+2+3+4+5 + 2+3+4 + 5+6+7+8+9+10;
		System.out.println("sum = " + sum3);
		
		int sum4 = sum(1, 5) + sum(2, 4) + sum(5, 10);
		System.out.println("sum = " + sum4);
		
		sum4 = sum(5, 1) + sum(2, 4) + sum(5, 10);
		System.out.println("sum = " + sum4);
	}
	public static int sum(int n) {
		int result = 0;
		for(int i=0; i<=n; i++) {
			result += i;
		}
		return result; //나를 호출한 곳으로 결과값을 되돌려준다. return을 만나면 메소드가 종료된다.
					   // 메소드의 원형에 리턴되는 값의 타입을 써주어야 한다.
	}
	
	public static int sum(int n, int m) {
		int result = 0;
		if(n<m) {
			for(int i=n; i<=m; i++) {
				result += i;
			}
		} else if(n>m) {
			for(int j = m; j<=n; j++) {
				result += j;
			}
		}
		return result; //나를 호출한 곳으로 결과값을 되돌려준다. return을 만나면 메소드가 종료된다.
					   // 메소드의 원형에 리턴되는 값의 타입을 써주어야 한다.
	}
}
