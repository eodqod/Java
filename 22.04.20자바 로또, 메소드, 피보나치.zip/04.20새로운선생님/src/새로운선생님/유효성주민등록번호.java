package 새로운선생님;

import java.util.Scanner;

public class 유효성주민등록번호 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		System.out.print("주민번호를 -없이 입력 : ");
		String id = sc.nextLine(); //엔터전까지 입력받는다.(빈칸까지 입력 가능)
		
		// 숫자로만 13자리를 입력받았는지 판단하는 코드가 있어야 한다. 여기서는 생략
		
		int sum = 0;
		for(int i=0; i<12; i++) {
			sum += (id.charAt(i)-'0') * (i%8+2);
			System.out.printf("%d * %d = %d\n", id.charAt(i)-'0', i%8+2, (id.charAt(i)-'0') * (i%8+2));
		}
		
		sum = (11-sum%11)%10;
		
		System.out.println(id.charAt(12)==sum+'0' ? "맞는번호" : "틀린번호");
		
	}
	

}
