package 새로운선생님;

import java.util.Random;

public class 불법카드놀이문제 {

	public static void main(String[] args) {
		// 40명의 인원을 무작위로 섞어서 10명씩 4개팀으로 나누어서 출력하시오
		int emp[] = new int[40];
		Random rnd = new Random();
		int t;
		for(int j=0; j<4; j++) {		// 팀수
			for(int i=0; i<10; i++) {	// 팀당 인원수
				do {
					t = rnd.nextInt(emp.length);
				}while(emp[t] != 0);
				emp[t] = j;				// 팀번호 할당
			}
		}
		
		for(int i=0; i<4; i++) print(emp, i);  // 반복문으로 각각의 팀별 출력
		
	}
	// 배열과 팀 번호를 인수로 받아 해당 팀만 출력
	private static void print(int[] ar, int team) {
		String[] names = "백청홍황".split("");
		System.out.print(names[team]+"팀 : ");
		for(int i=0; i<ar.length; i++) {
			if(ar[i]==team) System.out.printf("%3d", i+1);
		}
		System.out.println();
		System.out.println("-".repeat(40));
	}
}
