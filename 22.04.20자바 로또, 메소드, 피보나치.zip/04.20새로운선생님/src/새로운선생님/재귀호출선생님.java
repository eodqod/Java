package 새로운선생님;
/*
 * 재귀호출 메서드 : 자신이 자신을 호출하는 메서드!!!
 *                   잘쓰면 약!!!! 잘못쓰면 독!!!!
 */
public class 재귀호출선생님 {
	public static void main(String[] args) {
		System.out.println("5! = " + factorial1(5));
		System.out.println("5! = " + factorial1(5));
		System.out.println("6번째 피보나치 수열 : " + fibo1(6));
		System.out.println("6번째 피보나치 수열 : " + fibo2(6));
		System.out.println();
		System.out.println("6번째 피보나치 수열 : " + fibo1(8));
		System.out.println("130번째 피보나치 수열 : " + fibo2(8));
		
		recursive(5);
		System.out.println();
		recursive(8);
		System.out.println();
		
	}
	//메소드를 호출하면 stack에 메소드의 주소가 저장이 되어 실행된다.
	//stack은 LIFO(Last In First Out)의 자료구조이다. 후입선출구조
	//문제 5 4 3 2 1 2 3 4 5 를 출력하는 메서드를 재귀호출로 작성하시오
	public static void recursive(int n) {
		System.out.printf("%5d", n);
		if(n==1) return;
		recursive(n-1);
		System.out.printf("%5d", n);
	}
	
	// n!을 구하는 일반메서드
	public static long factorial1(int n) {
		long result = 1;
		while(n>0) result *= n--;
		return result;
	}
	
	// n!을 구하는 재귀호출 메서드
	public static long factorial2(long n) {
		return n<=1 ? 1 : n * factorial2(n-1);
	}
	
	// n번째 피보나치 수열의 값을 구하는 일반 메서드 (피보나치 수열의 시작값은 1부터이다) 
	public static long fibo1(int n) {
		System.out.println("fibo1(" + n+") 호출");
		long first = 0, second = 1;
		while(n>0) {
			second = first + second;
			first = second - first;
			n--;
		}
		return first;
	}
	
	// n번째 피보나치 수열의 값을 구하는 재귀호출 메서드(피보나치 수열의 시작값은 1부터이다) 
	public static long fibo2(int n) {
		System.out.println("fobo2(" + n+") 호출");
		return n==1||n==2 ? 1 : fibo2(n-2) + fibo2(n-1);
	}
}
