package 새로운선생님;
import java.util.Scanner;

/*
피보나치 수열 구하기
피보나치 수열이란, 첫 번째 항의 값이 0이고 두 번째 항의 값이 1일 때, 이후의 항들은 이전의 두 항을 더한 값으로 이루어지는 수열을 말한다.
예) 0, 1, 1, 2, 3, 5, 8, 13
인풋을 정수 n으로 받았을때, n 이하까지의 피보나치 수열을 출력하는 프로그램을 작성하세요

풀이방법
-------- 
1. 정수 n을 입력받는다.
2. 변수 두개를 선언하여 첫번째 정수에는 0, 두번째 정수에는 1로 초기화한다.
3. 첫번째 정수를 출력한다.
4. 임시변수에 두번째 변수를 피신 시킨다.
5. 첫번째 변수와 두번째 변수를 더해서 두번째 변수에 넣는다.
6. 피신시킨 값을 첫번째 변수에 넣는다.
7. 첫번째 변수값이 n이 넘지 않을때 3~6번을 반복한다. 
 */
public class 피보나치선생님 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("양의 정수 입력 : ");
		int n = sc.nextInt();  // 1번 해결
		int first=0, second = 1, temp; // 2번 해결
		while(first<n) {
			System.out.printf("%5d", first); // 3번 해결
			temp = second; // 4번 해결
			second = first + second; // 5번 해결
			first = temp; // 6번 해결
		} // 7번 해결
		sc.close();
	}
}
