package 새로운선생님;

import java.util.Arrays;
import java.util.Random;

public class 로또3 {

	public static void main(String[] args) {
		int[] lotto = new int[45];
		Random random = new Random();
		
		int temp;
		for(int i=0; i<6; i++) {   // 6개 번호 필요
			do {
				temp = random.nextInt(lotto.length);  // 0~44사이의 난수
			}while(lotto[temp] != 0);	  // 배열의 지정 위치값이 0이 아닌동안 반복 ==> 0이 있는 위치를 찾는다.
			lotto[temp] = 1;			  // 그곳에 1을 넣는다.
			
		}								  //이 반복문이 종료되면 6군데만 1이 들어가 있다.
		
		for(int i=0; i<lotto.length; i++) {
			if(lotto[i] == 1) System.out.printf("%3d", i+1);  // 1의 위치를 찍는다.
		}
		System.out.println();
	}

}
