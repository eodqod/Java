package 넷째날;

import java.util.Arrays;
import java.util.Random;

public class selectionSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random rnd = new Random();
		int ar[] = new int[10];
		for(int i=0; i<ar.length; i++) ar[i] = rnd.nextInt(101); //난수로 배열 채우기
		System.out.println("정렬전 : " + Arrays.toString(ar));
		for(int i=0; i<ar.length-1; i++) { // n-1회전
			int k = i;
			for(int j=i+1; j<ar.length; j++) { // 나의 오른쪽 첫번째부터 마지막까지
				if(ar[j]>ar[k]) { // 제일 적은값의 위치를 찾는다.
					k = j; // 적은값의 위치를 가진다.
				}
			}
			// 현재값과 제일 적은값을 교환한다.
			int temp = ar[k];
			ar[k] = ar[i];
			ar[i] = temp;
			System.out.println(i+1 + "회전 : " + Arrays.toString(ar));
		}
		System.out.println("정렬후 : " + Arrays.toString(ar));

	}

}
