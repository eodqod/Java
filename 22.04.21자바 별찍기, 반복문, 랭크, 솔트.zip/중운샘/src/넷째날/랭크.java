package 넷째날;

import java.util.Arrays;
import java.util.Random;

public class 랭크 {

	public static void main(String[] args) {
		Random rnd = new Random();
		int ar[] = new int[10];
		int rank[] = new int[10];
		Arrays.fill(rank, 1); // 처음은 누구나 1등이다.
		for(int i=0; i<ar.length; i++) ar[i]=rnd.nextInt(101); //난수로 배열 채우기
		System.out.println("점수 : "+Arrays.toString(ar));
//		System.out.println("점수 : "+Arrays.toString(rank));
		
		//100번의 반복횟수로 구해진다.
		for(int i=0; i<ar.length; i++) {
			for(int j=0; j<ar.length; j++) {
				if(ar[i]<ar[j]) {
					rank[i]++;
				}
			}
		}
		System.out.println("순위 : "+Arrays.toString(rank));
		
		//45번만으로 가능하다.
		Arrays.fill(rank, 1);
		for(int i=0; i<ar.length-1; i++) {
			for(int j=i+1; j<ar.length; j++) {
				if(ar[i]<ar[j]) {
					rank[i]++;
				}else if(ar[i]>ar[j]) {
					rank[j]++;
				}
			}
		}
		System.out.println("순위 : "+Arrays.toString(rank));
	}

}
