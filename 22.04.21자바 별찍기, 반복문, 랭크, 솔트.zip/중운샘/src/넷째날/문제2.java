package 넷째날;

import java.util.Arrays;

public class 문제2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. "
				+ "Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, "
				+ "when an unknown printer took a galley of type and scrambled it to make a type specimen book. "
				+ "It has survived not only five centuries, but also the leap into electronic typesetting, "
				+ "remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets "
				+ "containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker "
				+ "including versions of Lorem Ipsum.";
		int ar[] = new int[26];				//26글자
		for(char ch : str.toCharArray()) {  //문자열.toCharArray() = 문자배열로 만든다.
			if(ch>='a' && ch<='z' || ch>='A' && ch<='Z') {  //알파벳이라면
				if(ch>='A' && ch<='Z') {  // 대문자라면
					ch = (char)(ch+32);   // 소문자로 바꾼다.
				}
				// 1줄만 추가하면 된다.
				ar[ch-'a']++; // 'a' - 'a' = 0 : 배열의 첫번째값이 증가
							  // 'b' - 'a' = 1 : 배열의 두번째값이 증가 
			}
		}
		System.out.println(Arrays.toString(ar));
		
		for(char i='a'; i<='z'; i++) {
			System.out.println(i+" : "+ar[i-'a']+"개");
		}
		
	}

}
