package 넷째날;

public class 반복문5 {

	public static void main(String[] args) {

		int cnt = 0; // 출력 개수
		//2~100까지 반복
		for(int i=2 ; i<=100; i++) {
//			for(int j=2; i%j!=0; j++); // 나누어 떨어지는 순간 반복문이 종료
			int j=2;
			while(i%j!=0) ++j;
			if(i==j) { // 나누는 수가 자기 자신이라면 소수다.
				System.out.printf("%4d", i);
				if(++cnt%5==0) System.out.println(); // 출력개수가 5의 배수면 줄바꿈
			}
		}
	}

}
