package 넷째날;

import java.util.Scanner;

public class 별찍기 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//행열을 입력받아 *을 사각형으로 출력하시오 
		//3 4
		//****
		//****
		//****
		
		Scanner sc = new Scanner(System.in);
		int row = sc.nextInt();
		int col = sc.nextInt();
		
		for(int i=0; i<row; i++) {		// 줄수
			for(int j=0; j<col; j++) {  // 칸수
				System.out.print("★");
			}
			System.out.println();
		}
		sc.close();
		
	}

}
