package 넷째날;


public class 별찍기2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//행열을 입력받아 *을 사각형으로 출력하시오 
		//3 4
		//****
		//****
		//****
		int row = 10;
		for(int i=1; i<=row; i++) {			// 줄수
			//공백찍고
			for(int j=0; j<10-i; j++)   // 칸수
				System.out.print("  ");
			//별찍고
			for(int j=1; j<= i*2-1; j++) {
				System.out.print("★");
			}
			System.out.println();
		}
	}
}
