package 넷째날;

public class 반복문2 {

	public static void main(String[] args) {
		/*
		 * for(초기식1;종료식2;증감식3){종료식이 참인경우 실행할 명령들4(1줄일때 중괄호 생략 가능)}
		 * 실행순서 : 1 2 4 3 / 2 4 3....
		 */
		// 1~100까지 합을 구하는 여러가지 방법
		int sum = 0, i = 1;
		while(i<=100) {
			sum += i++;
		}
		System.out.println("1~100까지 합 : " + sum); // 방법 1
		
		sum = i = 0;
		while(i<100) sum += ++i;
		System.out.println("1~100까지 합 : " + sum); // 방법 2
		
		sum = i = 0;
		do {
			sum += ++i;
		}while(i<100);
		System.out.println("1~100까지 합 : " + sum); // 방법 3

		sum = i = 0;
		while(true) {
			sum += ++i;
			if(i>=100) break;
		}
		System.out.println("1~100까지 합 : " + sum); // 방법 4

		sum = i = 0;
		for(;;) {	// for문에서 ;은 절대 생략 불가 : 무한루프
			sum += ++i;
			if(i>=100) break;
		}
		System.out.println("1~100까지 합 : " + sum); // 방법 5

		for(sum = i = 0;;) {
			sum += ++i;
			if(i>=100) break;
		}
		System.out.println("1~100까지 합 : " + sum); // 방법 6

		for(sum = i = 0;; ++i) {
			sum += i;
			if(i>=100) break;
		}
		System.out.println("1~100까지 합 : " + sum); // 방법 7
		
		for(sum = i = 0; i<=100; ++i) {
			sum += i;
		}
		System.out.println("1~100까지 합 : " + sum); // 방법 8
		
		sum = 0;
		for(i = 1; i<=100; ++i) {
			sum += i;
		}
		System.out.println("1~100까지 합 : " + sum); // 방법 9

		
		for(sum = 0, i = 1; i<=100; sum += i++);
		System.out.println("1~100까지 합 : " + sum); // 방법 10
	}

}
