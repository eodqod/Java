package 넷째날;

import java.util.Random;

public class 랭크3 {

	public static void main(String[] args) {
		Random rnd = new Random();
		int score[][] = new int[11][12];
		arraysPrint(score);
		System.out.println("-".repeat(92));
		// 성적은 10행 10열 이므로 난수로 채워기
		for(int i=0; i<score.length-1; i++) {
			for(int j=0; j<score[i].length-2; j++) {
				score[i][j] = rnd.nextInt(101);
			}
		}
		arraysPrint(score);
		System.out.println("-".repeat(92));
		// 가로합과 세로합을 구해야한다.
		for(int i=0; i<score.length-1; i++) {
			for(int j=0; j<score[i].length-2; j++) {
				score[i][10] += score[i][j]; // 가로합
				score[10][j] += score[i][j]; // 세로합
			}
		}
		arraysPrint(score);
		System.out.println("-".repeat(92));
		
		//석차 구하기
		for(int i=0; i<score.length-1; i++) score[i][11] = 1; // 처음은 1등
		for(int i=0; i<score.length-1; i++) {
			for(int j=i+1; j<score.length-1; j++) {
				if(score[i][10]<score[j][10]) {
					score[i][11]++;
				}else if(score[i][10]>score[j][10]) {
					score[j][11]++;
				}
			}
		}
		arraysPrint(score);
		System.out.println("-".repeat(92));
	}

	private static void arraysPrint(int[][] ar) {
		for(int i=0; i<ar.length-1; i++) { //-1은 왜 했을까 ? 과목합계는 출력할 필요가 없다.
			for(int j=0; j<ar[i].length; j++) {
				System.out.printf("%7d", ar[i][j]);
				// 합계를 출력한 다음만 평균을 계산해서 출력하면 된다.
				if(j==10) {
					System.out.printf("%7.2f", ar[i][10]/10.0);
				}
			}
			System.out.println();
		}
		// 과목평균을 출력
		for(int j=0; j<ar[0].length-2; j++) {
			System.out.printf("%7.2f", ar[10][j]/10.0);
		}
		System.out.println();
	}

}
