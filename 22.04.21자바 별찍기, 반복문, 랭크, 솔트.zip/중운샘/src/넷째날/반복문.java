package 넷째날;

public class 반복문 {

	public static void main(String[] args) {
		boolean flag = false;
		// while(조건){ 조건이 참인동안 실행할 명령들(1줄일때 중괄호 생략 가능)}
		// do{조건이 참인동안 실행할 명령들(1줄인 경우 중괄호 생략가능)}while(조건);
		
		while(flag) {
			System.out.println("나는 실행이 될까요(while)?");
		}
		//두 명령의 차이는 1회 실행 보장에 있다.
		do {
			System.out.println("나는 실행이 될까요(do~while)?");
		}while(flag);
		
		int n;			// 초기화 안함
		while(n>0) {	// 무조건 에러. 지역변수는 초기화 되어야 사용 가능
			
		}
		
		do {			// 이건 에러가 아닐 수도 있다.
			n=10;		// 여기에서 n의 값을 초기화 한다면 에러가 아니다.
		}while(n>0);
		
	}

}
