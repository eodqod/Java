package 넷째날;

public class 반복문6 {

	public static void main(String[] args) {
		
		int cnt = 0; // 출력 개수
		//2~100까지 반복
		for(int i=2 ; i<=100; i++) {
			boolean flag = true; // 일단은 소수라고 가정
			for(int j=2; j<=i/2; j++) { // n/2까지만 반복
				if(i%j==0) {
					// 나누어 떨어졌으면 소수가 아니다.
					flag = false;
					break;
				}
			}
			
			if(flag) { // 나누어진 적이 없다. 소수다.
				System.out.printf("%4d", i);
				if(++cnt%5==0) System.out.println(); // 출력개수가 5의 배수면 줄바꿈
			}
		}
	}
}
