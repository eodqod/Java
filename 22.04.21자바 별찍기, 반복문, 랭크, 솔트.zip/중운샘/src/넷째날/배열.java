package 넷째날;

public class 배열 {
/*
 * 과제 : 3행 3열의 배열을 만들고 아래와 같이 초기화 한 후에
 * 1 2 3
 * 4 5 6
 * 7 8 9
 * 
 * 90도 돌려서 출력하고
 * 7 4 1
 * 8 5 2
 * 9 6 3
 * 
 * 180도 돌려서 출력하고
 * 9 8 7
 * 6 5 4
 * 3 2 1
 * 
 * 270도 돌려서 출력하는 프로그램을 작성하시오
 * 3 6 9
 * 2 5 8
 * 1 4 7
 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [][] arrnum1 = new int[3][3]; 
		
		
		for(int i=0; i<arrnum1.length; i++) {		// 줄수
			for(int j=0; j<arrnum1.length; j++) {  // 칸수
				System.out.print("1");
			}
			System.out.println();
		}
	}
}
