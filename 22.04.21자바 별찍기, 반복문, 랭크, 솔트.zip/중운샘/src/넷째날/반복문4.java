package 넷째날;

public class 반복문4 {

	public static void main(String[] args) {
		/*
		 * 1~100 사이의 소수를 1줄에 5개씩 출력하는 프로그램 작성
		 * 소수란 1과 자신만을 약수로 가지는 수이다. 2, 3, 5, 7, 11등등
		 */
		int cnt = 0; // 출력 개수
		//2~100까지 반복
		for(int i=1 ; i<=100; i++) {
			// i의 약수의 개수를 센다. 어떻게? 나누어서 떨어지면 약수다.
			int count = 0; // 약수의 개수
			// 1부터 i까지의 수로 나누어 떨어지는지 검사하여 나누어 떨어지면 출력한다.
			for(int j=1; j<=i; j++) {
				if(i%j==0) count++;
			}
			if(count==2) {
				System.out.printf("%4d", i);
				if(++cnt%5==0) System.out.println(); // 출력개수가 5의 배수면 줄바꿈
			}
		}
	}

}
