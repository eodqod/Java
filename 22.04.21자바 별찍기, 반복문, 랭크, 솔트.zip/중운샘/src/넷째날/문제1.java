package 넷째날;

import java.util.Arrays;
import java.util.Scanner;

public class 문제1 {

	public static void main(String[] args) {
		int a,b,c;
		Scanner sc = new Scanner(System.in);
		a = sc.nextInt();
		b = sc.nextInt();
		c = sc.nextInt();
		int result = a*b*c;
		int ar[] = new int[10];
		while(result>0) {
			ar[result%10]++;  // 뒤의 1자리를 잘라낸다.
							  //그 값이 0이면 0번째 배열값이 1증가
			result/=10;
		}
		System.out.println(Arrays.toString(ar));
		sc.close();

	}

}
