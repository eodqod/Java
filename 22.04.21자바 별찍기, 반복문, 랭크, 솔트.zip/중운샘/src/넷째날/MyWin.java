package 넷째날;

import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class MyWin {

	public static void main(String[] args) {
		JFrame frame = new JFrame("내가만든 윈도우");
		frame.setSize(500, 600);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
		JButton button = new JButton("눌러봐");
			
		
	}

}
