package 넷째날;

import java.util.Arrays;

public class 반복문9 {

	public static void main(String[] args) {
		/*
		 * JDK 1.5에서 추가된 향상된 for문
		 * for(변수 : Collection){Collection안의 모든 원소가 반복될때까지 반복된다.}
		 */
		
		for(String str : "재미없는 자바".split("")) {
			System.out.println(str);
		}
		for(char str : "재미없는 자바".toCharArray()) {
			System.out.println(str);
		}
		for(int i : new int [] {1,2,3,4,5}) {
			System.out.println(i);
		}
		for(int i : Arrays.asList(new Integer[] {1,2,3,4,5})) {
			System.out.println(i);
		}

	}

}
