package 넷째날;

public class 반복문7 {

	public static void main(String[] args) {

		long start = System.currentTimeMillis(); // 1/1000초 단위로 시간을 구해준다.
		int cnt = 0; // 출력 개수
		//2~100까지 반복
		outter: //반복문에 꼬리표를 단다.
		for(int i=2 ; i<=100; i++) {
			for(int j=2; j<=i/2; j++) { // n/2까지만 반복
				if(i%j==0) continue outter;
			}
			System.out.printf("%4d", i);
			if(++cnt%5==0) System.out.println(); // 출력개수가 5의 배수면 줄바꿈
		}
		System.out.println("경과시간 : " + (System.currentTimeMillis() - start) + "ms");
	}
}
