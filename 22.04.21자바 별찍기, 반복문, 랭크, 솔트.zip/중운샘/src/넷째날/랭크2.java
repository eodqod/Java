package 넷째날;

import java.util.Arrays;
import java.util.Random;

public class 랭크2 {

	public static void main(String[] args) {
		Random rnd = new Random();
		// 2차원 배열은 1차원 배열의 배열이다. 
		int ar[][] = new int[2][10];
		System.out.println(ar.length+"행");
		System.out.println(ar[0].length+"열");
		Arrays.fill(ar[1], 1); // 처음은 누구나 1등이다.
		for(int i=0; i<ar[0].length; i++) ar[0][i]=rnd.nextInt(101); //난수로 배열 채우기
		
		// 다차원 배열을 출력시 Arrays.deepToString()메소드 사용
		System.out.println("점수 : "+Arrays.deepToString(ar));
		System.out.println();
		
		//석차를 구하기 전
		arraysPrint(ar);
		
		//석차를 구하기
		for(int i=0; i<ar[0].length-1; i++) {
			for(int j=i+1; j<ar[0].length; j++) {
				if(ar[0][i]<ar[0][j]) {
					ar[1][i]++;
				}else if(ar[0][i]>ar[0][j]) {
					ar[1][j]++;
				}
			}
		}
		//석차를 구한 후
		arraysPrint(ar);
	}

	private static void arraysPrint(int[][] ar) {
		for(int i=0; i<ar.length; i++) {
			System.out.print(i==0 ? "점수 : " : "석차 : ");
			for(int j=0; j<ar[i].length; j++) {
				System.out.printf("%4d", ar[i][j]);
			}
			System.out.println();
		}
	}

}
