package 넷째날;

public class 반복문3 {

	public static void main(String[] args) {
		/*
		 * 1~100 사이의 소수를 1줄에 5개씩 출력하는 프로그램 작성
		 * 소수란 1과 자신만을 약수로 가지는 수이다. 2, 3, 5, 7, 11등등
		 */
		//1~100까지 반복
		for(int i=1 ; i<=100; i++) {
			// i의 약수의 개수를 센다. 어떻게? 나누어서 떨어지면 약수다.
			int count = 0;
			System.out.println(i+"의 약수 : ");
			// 1부터 i까지의 수로 나누어 떨어지는지 검사하여 나누어 떨어지면 출력한다.
			for(int j=1; j<=i; j++) {
				if(i%j==0) {
					count++;
					System.out.printf("%4d", j);
				}
			}
			System.out.println(" : "+ count +"개" + (count==2 ? "소수" : "합성수"));
		}
	}

}
