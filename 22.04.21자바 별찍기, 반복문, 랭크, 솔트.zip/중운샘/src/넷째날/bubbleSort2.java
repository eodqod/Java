package 넷째날;

import java.util.Arrays;
import java.util.Random;

public class bubbleSort2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random rnd = new Random();
		int ar[] = new int[10];
		for(int i=0; i<ar.length; i++) ar[i] = rnd.nextInt(101); //난수로 배열 채우기
		System.out.println("정렬전 : " + Arrays.toString(ar));
		for(int i=0; i<ar.length-1; i++) { // n-1회전
			boolean flag = true; // 이미 정렬되었다고 가정
			for(int j=0; j<ar.length-1-i; j++) { // 첫번째부터 마지막 전까지 1개씩 줄이면서
				if(ar[j]>ar[j+1]) { // 현재와 현재 다음것을 비교
					int temp = ar[j+1];
					ar[j+1] = ar[j];
					ar[j] = temp;
					flag = false; // 교환이 이루어졌다면 아직 정렬중
				}
			}
			if(flag) break; //flag값이 참이면 한번도 교환이 이루어지지 않는다. 즉 정렬 종료
			System.out.println(i+1 + "회전 : " + Arrays.toString(ar));
		}
		System.out.println("정렬후 : " + Arrays.toString(ar));
	}

}
