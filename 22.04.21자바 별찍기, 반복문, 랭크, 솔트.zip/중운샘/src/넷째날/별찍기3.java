package 넷째날;

import java.util.Scanner;

public class 별찍기3 {

	public static void main(String[] args) {
		//(1) + (1+2) + (1+2+3) + ... (1+...+100) = ?
		//반복문 1개로 풀기
		//반복문 2개로 풀기
		
		int sum=0;
		for(int i=1; i<=100; i++) {
			for(int j=1; j<=i; j++) {
				System.out.print(j+" ");
				sum+=j;
			}
			System.out.println();
		}
		System.out.println("정답 : "+sum);
		
		int total=0;
		sum=0;
		for(int i=1; i<=100; i++) {
			total+=i;
			sum+=total;
			
		}
		System.out.println("정답 : "+sum);
		
	}
}
