package kr.human.lambda;

public class Ex03_lambda03 {
	// ==> 인수가 없고 리턴값도 없다. ==> Runnable를 사용한다.
	public static void main(String[] args) {
		System.out.println("하하하하");
		System.out.println("\n");	//빈줄 두개 출력
		System.out.println("하하하하");
		System.out.println("-".repeat(40));
		
		//람다로 표현
		Runnable blankDoubleLine = () -> System.out.println("\n");
		System.out.println("하하하하");
		blankDoubleLine.run();	//빈줄 두개 출력
		System.out.println("하하하하");
		System.out.println("-".repeat(40));
		
		Runnable line = () -> System.out.println("-".repeat(40));
		System.out.println("하하하하");
		line.run();  //선그리기
		System.out.println("하하하하");
		line.run();  //선그리기
		
	}
}
