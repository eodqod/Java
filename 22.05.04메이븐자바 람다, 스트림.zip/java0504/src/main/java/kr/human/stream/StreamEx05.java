package kr.human.stream;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.jsoup.select.Collector;

public class StreamEx05 {
	public static void main(String[] args) {
		//스트림은 읽기만 가능하다. 변경하지 못한다. 그래서 중간연산을 하면 새로운 스트림이 리턴된다.
		List<Integer> list = Arrays.asList(11,22,3,44,55,66,27,58);
		//Collect연산  : 만들어라
		//리스트를 스트림으로 만들어서 정렬한 다음에 다시 리스트로 만들어라
		List<Integer> sortedList = list.stream().sorted().collect(Collectors.toList());
		System.out.println(list);
		System.out.println(sortedList);
		
		System.out.println(sortedList.stream().count() + "개"); //최종연산
		
		//peek(Consumer<? super T> action)메소드를 이용하여 디버깅 가능
		int sum = Stream.of(1,2,3,4,5,6,7,8,9,10)
				  .peek(n->System.out.println("가져오기 : " + n))
				  .filter(n->n%2==1)  //거르기
				  .peek(n->System.out.println("거르기 : " + n))
				  .map(n->n*n)		  //각각의 요소를 변경하여 새로운 스트림을 만들어낸다.
				  .peek(n->System.out.println("변환 : " + n))
				  .reduce(0, Integer::sum); //모든 요소에 대하여 반복하는 최종연산
		System.out.println("합계 : " + sum); //1제곱+3제곱+5제곱+7제곱+9제곱
		
	}
}
