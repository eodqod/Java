package kr.human.stream;

import java.util.Arrays;
import java.util.List;

/*
reduce () 연산은 스트림의 모든 요소를 ​​결합하여 단일 값을 생성합니다.
T  reduce(T identity, BinaryOperator<T> accumulator)
<U> U reduce(U identity, BiFunction<U,? super  T,U> accumulator, BinaryOperator<U> combiner)
Optional<T> reduce(BinaryOperator<T> accumulator)
*/
public class StreamEx08 {
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
		int sum = list.stream().reduce(0, Integer::sum);
		System.out.println("합계 : " + sum);
		
		System.out.println("합계 : " + list.stream().reduce(0, Integer::sum));
		
		//사원들의 수입합계
		System.out.println("합계 : " + 
				Employee.persons().stream().map(e -> e.getIncome()).reduce(0.0, Double::sum));
		
		System.out.println("합계 : " + 
				Employee.persons().stream()
				.reduce(0.0, (pSum, person) -> pSum+person.getIncome(), Double::sum));
		
	}
}
