package kr.human.stream;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.jsoup.select.Collector;

public class StreamEx06 {
	public static void main(String[] args) {
		//사용자가 만든 클래스를 이용한 스트림 작업
		List<Employee> list = Employee.persons();
		System.out.println("원본 : " + list);
		
		//스트림을 이용한 전체 출력
		list
		.stream()
		.forEach(e->System.out.println(e.getId() + " : " + e.getName()));
		System.out.println("-".repeat(60));
		
		//리스트 중에서 여자만 출력해라
		list
		.stream()
		.filter(Employee::isFemale)
		.forEach(e->System.out.println(e.getId() + " : " + e.getName() + ", " + e.getGender()));
		System.out.println("-".repeat(60));
		//리스트 중에서 남자만 출력해라
		list
		.stream()
		.filter(e->e.getGender()==Employee.Gender.MALE)
		.forEach(e->System.out.println(e.getId() + " : " + e.getName() + ", " + e.getGender()));
		System.out.println("-".repeat(60));
		
		//값 변경
		list
		.stream()
		.filter(Employee::isFemale) //여자만
		.forEach(e->e.setIncome(e.getIncome()*1.1)); //10% 증가 : 최종연산
		
		//다시 출력
		list
		.stream()
		.forEach(e->System.out.println(e.getId() + " : " + e.getName() + " : " + e.getIncome()));
		System.out.println("-".repeat(60));
		
		//map을 이용하여 값 변경 후 출력하기
		list
		.stream()
		.map(Employee::getUpperName)
		.forEach(e->System.out.println(e));
		System.out.println("-".repeat(60));
		
		//남자 중에서 수입이 5000이상인 사람의 이름과 수입을 출력하시오
		list
		.stream()
		.filter(e->e.getGender()==Employee.Gender.MALE && e.getIncome()>=5000)
//		.filter(e->e.getGender()==Employee.Gender.MALE)
//		.filter(e->e.getIncome()>=5000)
		.forEach(e->System.out.println(e.getName() + ", " + e.getIncome()));
		System.out.println("-".repeat(60));
		
		
	}
}
