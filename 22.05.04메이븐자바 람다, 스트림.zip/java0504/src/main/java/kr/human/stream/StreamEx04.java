package kr.human.stream;

import java.util.Random;
import java.util.stream.Stream;

public class StreamEx04 {
	public static void main(String[] args) {
		//중간연산 : filter
		String str = "1234,qwerty,3,12,6";
		
		str
		.chars()
		.filter(n->!Character.isDigit((char)n) && ((char)n!=','))
		.forEach(n->System.out.print((char)n));
		System.out.println();
		
		str
		.chars()
		.filter(n->!"1234567890,".contains((char)n+""))
		.forEach(n->System.out.print((char)n));
		System.out.println();
		
	}
}
