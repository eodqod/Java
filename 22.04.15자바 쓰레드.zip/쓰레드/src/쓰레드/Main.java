package 쓰레드;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Runnable d = new Animal("강아지");
		Runnable d1 = new Animal("고양이");
		Runnable d2 = new Animal("여우");
		Runnable d3 = new Animal("늑대");
		
		Thread thread = new Thread(d);
		Thread thread1 = new Thread(d1);
		Thread thread2 = new Thread(d2);
		Thread thread3 = new Thread(d3);
		
		thread.start();
		thread1.start();
		thread2.start();
		thread3.start();
		
		//타이머를 만들고 걔는 걔 알아서 시간이 돌고
		//유저로부터 키보드 입력받는 쓰레드에서는 걔 알아서 입력을 받고
		//메인에서는 그 두개를 컨트롤
	}
	

}
