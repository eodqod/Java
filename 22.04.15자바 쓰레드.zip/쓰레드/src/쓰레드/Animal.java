package 쓰레드;

class Animal implements Runnable{
	String name;

	Animal(String name) {
		this.name = name;
	}

	@Override
	public void run() {
		try {
			for(int i=0; i<5; i++) {
				System.out.println(name);
				Thread.sleep(1000);
			}
		}catch(Exception e) {
			System.out.println(e.toString());
		}
		System.out.println("쓰레드 종료 : "+name);
	}
}
