package 쓰레드;

import java.util.Scanner;

public class 예외 {
	
	public static void main(String[] args) {
//		double a = 5;
//		double b = 0;
//		double result = a/b;
//		System.out.println(result); //double일때 0으로 나오면 Infinity
		int a = 5;
		int b = 0;
		double result = 0;
		
		try {
			result = a/b;
		} catch(Exception e) { //exception은 어떤 예외든 다 처리
			System.out.println("0으로는 나눌수없습니다.");
		} finally {
			System.out.println(result);
		}
		
		int[] arr = {1,2,3};
		try {
			arr[5] = 5;
		} catch(Exception e){
			e.printStackTrace();
			System.out.println("5번째는 없습니다.");
		}
		
		System.out.println("제대로실행");
		
		multiplyFive();
		
//		유저로부터 숫자를 받아서 5를 곱해주는 함수를 만들어 보세요.
//		그런데 유저가 "백"이라는 문자열을 입력했을경우 프로그램이 터진다.
//		터지지않도록 해보시오.
		
	}
	
	public static int multiplyFive() {
		System.out.println("5를 곱할겁니다. 숫자를 입력해주세요.");
		Scanner sc = new Scanner(System.in);
		int input = 0;
		int result = 0;
		try {
			input = sc.nextInt();
			result = input * 5;
		} catch (Exception e) {
			System.out.println("숫자만 입력해주세요.");
			sc.nextLine(); //이게 있어야 예외를 잡고 다시 나타내준다.
			input = sc.nextInt();
			result = input * 5;
		} finally {
			System.out.println("결과 : "+result);
		}
		return result;
		
	}
	
	
}
