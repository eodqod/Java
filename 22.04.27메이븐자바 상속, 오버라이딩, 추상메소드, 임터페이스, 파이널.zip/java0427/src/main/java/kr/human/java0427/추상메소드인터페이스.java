package kr.human.java0427;

//다형성
//1. 동일한 부모를 가진다.
//2. 부모의 메소드를 오버라이딩한다.
//3. 부모의 변수에 자식 객체를 대입해서 자식을 컨트롤 한다.


abstract class Shape{
//추상 클래스 : 추상메소드를 1개 이상 갖는 클래스. 미완성 클래스이다. 객체생성X
//상속받는 자식클래스에게 의무를 부여한다. 반드시 오버라이딩하라고 정해준다.
   public static final double PI = 3.141592;
   //public void draw() { System.out.println("도형을 그립니다."); }
   abstract public void draw(); //내용이 없는 메소드 => 추상메소드. **규칙을 정하기 위해서** 만든다.
}

//interface : 추상클래스보다 추상도가 더 높은 클래스
//일반변수나 메소드를 가질 수 없다. 상수와 추상 메소드만으로 구성된다.
//interface는 상속이 아니라 '구현한다'(implements)라고 한다.
interface Graphic{
	double PI = 3.1415; //이건 가능하다. 앞에 public static final이 자동으로 붙는다.
	void move(); 		// public이 자동으로 붙는다.
	void remove();
}

interface Graphic2{
	double PI = 3.1415; //이건 가능하다. 앞에 public static final이 자동으로 붙는다.
	void rotate(); 		// public이 자동으로 붙는다.
}

//인터페이스의 상속
interface Graphics extends Graphic, Graphic2{ 
	//인터페이스끼리의 상속은 implements가 아니라 extends로 받는다.
	//extends는 원래 상속받는 방식이다.
	void resize();
}

class Point extends Shape implements Graphic, Graphic2{ //interface는 다중 구현이 가능하다.
   public void draw() { System.out.println("점을 그립니다."); }
	
	@Override
	public void move() {
	}
	@Override
	public void remove() {
	}
	@Override
	public void rotate() {
	}
}
class Line extends Shape{
   public void draw() { System.out.println("선을 그립니다."); }
}
class Circle extends Shape{
   public void draw() { System.out.println("원을 그립니다."); }
}
class Rectangle extends Shape{
   public void draw() { System.out.println("사각형을 그립니다."); }
}
public class 추상메소드인터페이스 {
   public static void main(String[] args) {
      Shape[] shapes = {new Point(),new Line(), new Circle(), new Rectangle()};
      
      for(Shape shape : shapes) {
         shape.draw();
      }
   }
}