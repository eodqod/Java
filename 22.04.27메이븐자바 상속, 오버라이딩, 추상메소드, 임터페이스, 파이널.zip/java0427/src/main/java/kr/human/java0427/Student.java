package kr.human.java0427;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Student extends Human{
	private String stuNo;
	
	public Student(String stuNo, String name) {
		super(name);			// 이름은 부모에 전달해서 초기화
		this.stuNo = stuNo;		// 학번은 자체 초기화
	}
	
	//오버라이딩 : 기능 변경
	public void thing() {
		System.out.println("이번 중간고사를 잘 봐야한텐데");
	}
	
	//기능 추가
	public void study() {
		System.out.println("하늘천 땅지 검을현 누룰황");
	}
}
