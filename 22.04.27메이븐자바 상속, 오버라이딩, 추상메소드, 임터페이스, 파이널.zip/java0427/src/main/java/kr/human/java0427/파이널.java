package kr.human.java0427;

//변수 앞 final : 변경 금지
//메소드 앞 final : 오버라이딩 금지
//클래스 앞 final : 상속 금지

class Some2{
	//메소드 앞에 final붙으면 오버라이딩 금지.
	final public void show() {
		System.out.println("나는 오버라이딩할 수 없다.");
	}
}

class ChildSome2 extends Some2{
	//에러다 : final메소드는 오버라이딩 금지.
//	public void show() {
//		System.out.println("나는 오버라이딩할 수 없다.");
//	}
}

final class FinalClass{
	
}

//클래스 앞에 final붙으면 상속 금지.
//에러다. : final클래스는 상속 금지.
//class ChildFinalClass extends FinalClass{
//	
//}

public class 파이널 {
	//변수명 앞에 final이 붙으면 변경 금지.
	static final int MAX = 1024;
	final static int MAX2 = 1024;
	//final과 static는 보통 같이 사용한다.
	//순서는 상관없다.
	public static void main(String[] args) {
		System.out.println("MAX = "+ MAX);
		//MAX = 2048; //에러, 변경 금지.
	}
}
