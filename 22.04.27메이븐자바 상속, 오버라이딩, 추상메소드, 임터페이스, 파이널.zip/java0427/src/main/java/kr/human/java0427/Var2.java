package kr.human.java0427;

public class Var2 {
	
	public void view() {
		Var var = new Var();
		// 같은 클래스 내부에서는 모두 사용가능하다.
		//System.out.println("private 변수 : " + var.priValue);
		//위의 private는 에러가 뜬다.
		//private는 그 클래스 내부에서만 사용가능하다.
		System.out.println("default 변수 : " + var.defValue);
		//default는 같은 패키지 내에서 사용가능하다.
		System.out.println("protected 변수 : " + var.proValue);
		//protected는 
		System.out.println("public 변수 : " + var.pubValue);
		//public는 어디서든 사용 가능하다.
	}
}
