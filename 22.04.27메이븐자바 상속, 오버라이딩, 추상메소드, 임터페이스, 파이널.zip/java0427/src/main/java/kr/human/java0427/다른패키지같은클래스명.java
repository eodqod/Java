package kr.human.java0427;

import static java.lang.System.out; // JDK 1.5이상
import kr.human.vo.PersonVO;

public class 다른패키지같은클래스명 {
	public static void main(String[] args) {
		//패키지가 다른 동일한 이름의 클래스를 여러개 사용하려면
		//많이 사용하는 패키지를 임포트하고 적게 사용하는 패키지는 
		//전체 이름을 써서 사용하면 된다.
		PersonVO vo1 = new PersonVO();
		kr.human.vo2.PersonVO vo2 = new kr.human.vo2.PersonVO();
		out.println(vo1);
		out.println(vo2);
		
		
	}
}
