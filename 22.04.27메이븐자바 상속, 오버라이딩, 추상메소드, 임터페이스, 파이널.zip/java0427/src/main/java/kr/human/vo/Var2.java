package kr.human.vo;

import kr.human.java0427.Var;

public class Var2 {
	
	public void view() {
		Var var = new Var(); //내가 만든 클래스라도 다른 패키지에 있으면 임포트 해야한다.
		// 같은 클래스 내부에서는 모두 사용가능하다.
		//System.out.println("private 변수 : " + var.priValue);
		//위의 private는 에러가 뜬다.
		//private는 그 클래스 내부에서만 사용가능하다.
		//System.out.println("default 변수 : " + var.defValue);
		//default는 같은 패키지 내에서 사용가능하다.
		//System.out.println("protected 변수 : " + var.proValue);
		//protected는 다른 패키지의 자식은 사용가능하다.
		//다른 패키지에서 extends로 상속받지 않으면 사용할수 없다.
		System.out.println("public 변수 : " + var.pubValue);
		//public는 어디서든 사용 가능하다.
	}
}
