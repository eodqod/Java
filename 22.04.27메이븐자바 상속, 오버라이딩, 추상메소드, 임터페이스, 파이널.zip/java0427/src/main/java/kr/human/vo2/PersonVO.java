package kr.human.vo2;

import lombok.Data;

@Data
public class PersonVO {
	private String name;
	private int age;
	private boolean gender;
}
