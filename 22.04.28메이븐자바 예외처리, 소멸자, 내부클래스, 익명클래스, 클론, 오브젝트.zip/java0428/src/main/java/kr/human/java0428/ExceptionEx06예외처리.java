package kr.human.java0428;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

//사용자가 만드는 예외 클래스
class SectionNotFoundException extends Exception{
	private static final long serialVersionUID = -5029678816499205512L;

	public SectionNotFoundException(String message) {
		super(message);
	}
}

public class ExceptionEx06예외처리 {
	public static void main(String[] args) {
		Scanner sc = null; //1. 변수 준비
		try {
			sc = new Scanner(new URL("https://www.naver.com").openStream()); //2. 열기
			while(sc.hasNextLine()) { //3. 사용
				System.out.println(sc.nextLine());
			}
			throw new SectionNotFoundException("글이 없네요");
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SectionNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally { //finally는 위에 return이 있어도 실행이 된다. 무조건 실행이 된다.
			sc.close(); //4. 닫기
		}
	}
}
