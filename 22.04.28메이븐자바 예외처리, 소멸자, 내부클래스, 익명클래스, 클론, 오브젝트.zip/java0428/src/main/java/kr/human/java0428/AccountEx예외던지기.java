package kr.human.java0428;

public class AccountEx예외던지기 {

	public static void main(String[] args) {
		Account예외던지기 account1 = new Account예외던지기("011-111", "이몽룡", 20_0000);
		account1.deposit(50000);
		
		System.out.println(account1);
		try {
			System.out.println(account1.withdraw(10_0000) + "원 출금");
			System.out.println(account1.withdraw(50_0000) + "원 출금");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			//e.printStackTrace();
		}

	}

}
