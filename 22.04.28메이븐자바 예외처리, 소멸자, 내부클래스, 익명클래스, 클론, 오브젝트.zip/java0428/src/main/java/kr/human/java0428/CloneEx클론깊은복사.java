package kr.human.java0428;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//clone메소드는 깊은 복사를 지원해준다.
//clone메소드로 깊은 복사가 가능하게 하려면 
//반드시 Cloneable인터페이스를 구현하고 clone메소드를 오버라이딩 해야한다.
//Cloneable인터페이스는 표시 인터페이스다. 깊은 복사를 수행하는 클래스이다 라고 표시만 한다.
//clone()메소드는 protected멤버이므로 접근이 불가능하다. 그래서 접근 가능하도록 오버라이딩 해야한다.
//**clone을 사용하려면 1. 인터페이스 구현 2. clone메소드 오버라이딩 이 두가지를 해야한다.

@AllArgsConstructor
@NoArgsConstructor
@Data
class CloneClass implements Cloneable{
	String name;

	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
}


public class CloneEx클론깊은복사 {
	public static void main(String[] args) {
		CloneClass c1 = new CloneClass("한사람");
		CloneClass c2 = c1; //얕은 복사 : 주소가 복사된다.
		System.out.println(c1 + " : " + c2);
		c2.setName("바뀐놈");
		System.out.println(c1 + " : " + c2); //둘 다 바뀜
		System.out.println();
		
		//깊은 복사 : 내용이 복사
		CloneClass c3 = new CloneClass();
		c3.setName(c1.getName());
		System.out.println(c1 + " : " + c3);
		c3.setName("다른놈");
		System.out.println(c1 + " : " + c3); //한 개만 바뀐. 다른 객체다.
		System.out.println();
		//깊은 복사할때 멤버가 많다면 노가다다. clone()메소드를 이용하면 된다.
		
		try {
			CloneClass c4 = (CloneClass) c1.clone();
			System.out.println(c1 + " : " + c4);
			c4.setName("또 다른놈");
			System.out.println(c1 + " : " + c4); //한 개만 바뀐. 다른 객체다.
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
	}
}
