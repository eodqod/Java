package kr.human.java0428;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ExceptionEx05예외처리 {
	public static void main(String[] args) {
		Scanner sc = null;
		try {
			sc = new Scanner(new File("src/main/resources/song.txt"));
			while(sc.hasNextLine()) {
				System.out.println(sc.nextLine());
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}finally {
			sc.close();
		}
	}
}
