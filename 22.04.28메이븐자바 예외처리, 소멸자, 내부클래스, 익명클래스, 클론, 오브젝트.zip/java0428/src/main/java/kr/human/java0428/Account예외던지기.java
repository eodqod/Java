package kr.human.java0428;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@AllArgsConstructor
@Getter
@ToString
public class Account예외던지기 { //은행 계좌 정보
	private String accountNo; //계좌번호
	private String ownerName; //예금주
	private int balance;	  // 잔액

	//입금
	public void deposit(int amount) {
		balance += amount;
	}
	
	//출금
	public int withdraw(int amount) throws Exception { //2.이 메소드는 예외를 발생시키는 메소드다.(예외 미루기)
													   //3.이 메소드를 사용하는 쪽에서 반드시 예외처리 하도록 강제한다.
		if(balance < amount) {
			//throw new Exception("잔액이 부족합니다."); //1.예외 던지기 throw-Exception를 이용한다. : 예외처리 필수
			throw new RuntimeException("잔액부족");		 //예외처리 선택 RuntimeException를 이용한다.
		}
		balance -= amount;
		return amount;
	}

}
