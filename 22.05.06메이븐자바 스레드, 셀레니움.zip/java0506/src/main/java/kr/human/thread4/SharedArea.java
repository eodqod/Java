package kr.human.thread4;


// 공유영역 : 은행의 모든 계좌 정보
public class SharedArea {
    Account account1;   // 1번 계좌
    Account account2;   // 2번 계좌
}
