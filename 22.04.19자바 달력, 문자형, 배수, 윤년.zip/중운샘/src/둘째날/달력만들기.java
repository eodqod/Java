package 둘째날;

import java.util.Calendar;
import java.util.Scanner;

public class 달력만들기 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int year, month, day, total = 0;
		Scanner sc = new Scanner(System.in);
		// 오늘의 날짜 구하기
		Calendar calendar = Calendar.getInstance();
		int yy = calendar.get(Calendar.YEAR); // 년도
		int mm = calendar.get(Calendar.MONTH) + 1; // 월(0~11)
		int dd = calendar.get(Calendar.DAY_OF_MONTH); // 일
		System.out.printf("오늘 : %04d년 %02d월 %02d일\n", yy, mm, dd);
		int cTotal = getTotalDay(yy, mm, dd);
		System.out.println("오늘까지의 총 일수 :" + cTotal);

		while (true) {
			System.out.println("년월일을 입력하시오(0은 종료)");
			year = sc.nextInt();
			if (year == 0)
				break;
			month = sc.nextInt();
			day = sc.nextInt();

			total = getTotalDay(year, month, day);

			System.out.println("총일수 : " + total + "일");
			switch (total % 7) {
			case 0:
				System.out.println("일");
				break;
			case 1:
				System.out.println("월");
				break;
			case 2:
				System.out.println("화");
				break;
			case 3:
				System.out.println("수");
				break;
			case 4:
				System.out.println("목");
				break;
			case 5:
				System.out.println("금");
				break;
			case 6:
				System.out.println("토");
				break;
			}

		}
		sc.close();
	}

	private static int getTotalDay(int year, int month, int day) {
		int total;
		// 총 일수를 구하자
		// 1. 전년도까지의 일수
		total = (year - 1) * 365 + (year - 1) / 4 - (year - 1) / 100 + (year - 1) / 400;
		// 2. 전월까지의 일수
		for (int i = 1; i < month; i++)
			total += getLastDay(year, i);
		// 3. 일수
		total += day;
		return total;
	}

	// 주어진 년월의 마지막 날짜 구하기
	private static int getLastDay(int year, int month) {
		int m[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }; // 월의 마지막 날짜
		m[1] = year % 400 == 0 || year % 4 == 0 && year % 100 != 0 ? 29 : 28;
		return m[month - 1];
	}
}
