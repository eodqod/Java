package 둘째날;

public class 반올림올림버림 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 반올림 : Math.round()을 이용한다.
		double d1 = 4567.56789;
		double d2 = -4567.56789;
		
		System.out.println(Math.round(d1));
		System.out.println(Math.round(d2));
		System.out.println("-".repeat(30));
		
		// 소수 둘째자리에서 반올림은 어떻게 할까 ?
		System.out.println(Math.round(d1*10)/10.0);
		System.out.println(Math.round(d1*100)/100.0);
		System.out.println(Math.round(d1*1000)/1000.0);
		System.out.println("-".repeat(30));
		
		// 1의자리 반올림 / 10의자리 반올림 ...
		System.out.println(Math.round(d1/10)*10);
		System.out.println(Math.round(d1/100)*100);
		System.out.println(Math.round(d1/1000)*1000);
		System.out.println("-".repeat(30));
		
		// 문제 : 8이상 올림 / 7이하 버림
		d1 = 77;
		System.out.println(Math.round((d1-3)/10)*10);
		d1 = 78;
		System.out.println(Math.round((d1-3)/10)*10);
		System.out.println("-".repeat(30));
		
		// 버림 : -5
		d1 = 78;
		System.out.println(Math.round((d1-5)/10)*10);
		d1 = 79;
		System.out.println(Math.round((d1-5)/10)*10);
		d1 = 78;
		System.out.println((int)(d1/10)*10);
		d1 = 79;
		System.out.println((int)(d1/10)*10);
		System.out.println("-".repeat(30));
		
		// 올림 : +4
		d1 = 70;
		System.out.println(Math.round((d1+4)/10)*10);
		d1 = 71;
		System.out.println(Math.round((d1+4)/10)*10);
		
		
	}

}
