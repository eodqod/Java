package 둘째날;

public class 멀티플 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(solution(10));
		System.out.println(solution(1000));
	}

	private static int solution(int n) {
		int result = 0;
//		for(int i=0; i<n; i++) {
//			if(i%3==0 || i%5==0) {
//				result += i;
//			}
//		}
		for(int i=0; i<n; i++) {
			if(i%3==0)
				result += i;
			if(i%5==0)
				result += i;
			if(i%15==0)
				result -= i;
		}
		return result;
		
	}
	

}
