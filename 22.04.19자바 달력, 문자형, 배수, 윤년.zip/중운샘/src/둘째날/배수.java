package 둘째날;

import java.util.Scanner;

public class 배수 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 1부터 100까지의 정수 중 한 개를 입력받기
		Scanner sc = new Scanner(System.in);
		int n = 0;
		do {
			n = sc.nextInt();
		}while(n<1 || n>100);
		int i=0;
		//100보다 작은 배수들을 차례로 출력하다가 0의 배수가 출력되면 프로그램 종료
		for(i=1; n*i<100 && n*i%10!=0; i++) {
			System.out.printf("%4d", n*i);
		}
		//마지막 10의 배수만 출력하는데 100미만이어야 한다.
		if(i*n<100) System.out.printf("%4d\n", i*n);	
		
		sc.close();
	}

}
