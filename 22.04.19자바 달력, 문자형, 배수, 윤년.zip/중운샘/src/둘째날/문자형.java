package 둘째날;

public class 문자형 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//문자형 : 2byte
		char ch = 'A';
		System.out.println(ch);
		ch = 97; //내부적으로 숫자가 저장된다. 출력 시키면 코드표에서 그 번호에 해당하는 문자를 출력한다.
		System.out.println(ch);
		
		ch = 48;
		System.out.println(ch);
		//위와 아래는 같다
		ch = '0';
		System.out.println(ch);
		
		ch = '강';
		System.out.println(ch);
		System.out.println(ch+0); // '강'은 44053번째 코드표
		System.out.println((char)(ch+1)); // '강' 다음 문자
		System.out.println((char)(ch+2));

		for(char c='ㄱ';c<='ㅎ'; c++) {
			System.out.print(c + " ");
		}
	
		//  에러다.
		// ch = '';  // 1문자가 꼭 들어가야 한다. 
		// ch = -90; //  0 ~ 65535 사이의 숫자만 들어간다.
		
		// 이스케이프 문자는 
		// 이스케이프 시퀀스를 따르는 문자들로서 다음 문자가 특수 문자임을 알리는 백슬래시(\)를 사용한다.
		ch = '\t';
		ch = '\n';
		ch = '\b';
		ch = '\\';
		ch = '\"';
		ch = '\'';
	}

}
