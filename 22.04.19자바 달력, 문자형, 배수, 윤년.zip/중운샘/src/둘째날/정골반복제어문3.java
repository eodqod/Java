package 둘째날;

import java.util.Scanner;

public class 정골반복제어문3 {
//	정수 20 개를 입력받아서 그 합과 평균을 출력하되 0 이 입력되면 20개 입력이 끝나지 않았더라도 
//  그 때까지 입력된 합과 평균을 출력하는 프로그램을 작성하시오.
//	평균은 소수부분은 버리고 정수만 출력한다.(0이 입력된 경우 0을 제외한 합과 평균을 구한다.)
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count=0, sum=0, n=0; //개수, 합계, 입력변수 선언
		Scanner sc = new Scanner(System.in);
		//입력
		while(count<20 && n!=0) {
			System.out.print(++count + "번째 정수 입력 : ");
			n = sc.nextInt();
			sum += n; //합계
		}//20개 이전이면서 0이 아닌 동안 반복
		
		System.out.println("합계 : "+sum);
		if(n==0) --count; //20개 이전에 0이 입력되면 감소
	}

}
