package 둘째날;

import java.util.Scanner;

public class 윤년 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = 0;
		n = sc.nextInt();
		if(n%4==0 && n%100!=0 || n%400==0) {
			System.out.println("윤년입니다.");
		}else {
			System.out.println("평년입니다.");
		}

		sc.close();
	}

}
