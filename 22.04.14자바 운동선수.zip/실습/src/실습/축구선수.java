package 실습;

public interface 축구선수 {
	public void kick();
}