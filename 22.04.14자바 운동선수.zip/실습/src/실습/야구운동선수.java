package 실습;

public class 야구운동선수 extends 사람 implements 야구선수{

	public 야구운동선수(String name, int age, String gender, int weight, int height) {
		super(name, age, gender, weight, height);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void catchBall() {
		// TODO Auto-generated method stub
		System.out.println(name+"의 배트 스피드 100km이상 입니다.");
		System.out.println(name+"의 구속(직구기준)은 120km이상 입니다.");
		
	}

}
