package 실습;

public class 축구운동선수 extends 사람 implements 축구선수{

	public 축구운동선수(String name, int age, String gender, int weight, int height) {
		super(name, age, gender, weight, height);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void kick() {
		// TODO Auto-generated method stub
		System.out.println(name+"은(는) 인스텝킥, 인프런트킥, 인사이드킥, 아웃사이드킥, 토킥, 힐킥이 가능합니다.");
		
	}

}

