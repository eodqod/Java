package 실습;

public interface 야구선수 {
	public void catchBall();
}
