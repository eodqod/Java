package 실습;

public interface 수영선수 {
	public void swimming();
}
