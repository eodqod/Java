package 실습;

public interface 농구선수 {
	public void dribble();
}
