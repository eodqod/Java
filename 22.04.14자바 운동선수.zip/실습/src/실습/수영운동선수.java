package 실습;

public class 수영운동선수 {

}
