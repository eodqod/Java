package 실습;

public class 사람 {
	protected String name;
	private int age;
	private String gender;
	private int weight;
	private int height;
	
	//생성자
	public 사람(String name, int age, String gender, int weight, int height) {
		super();
		// TODO Auto-generated constructor stub
		this.name = name;
		this.age = age;
		this.gender = gender;
		this.weight = weight;
		this.height = height;
	}

	//겟터셋터
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	//함수 걷기, 뛰기, 잠자기
	public void walk() {
		System.out.println(name+"이(가) 걷습니다.");
	}
	
	public void run(int fastRun) {
		System.out.printf(name+"이(가) 시속 %dkm로 뜁니다."+"\n",fastRun);
	}
	
	public void sleep() {
		System.out.println(name+"이(가) 하루 일과를 마치고 잠에 듭니다.");
	}
}
