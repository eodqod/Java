package 실습;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		축구운동선수 흥민손 = new 축구운동선수("손흥민", 28, "m", 80, 180);
		야구운동선수 현진류 = new 야구운동선수("류현진", 29, "m", 90, 185);
		
		흥민손.kick();
		현진류.catchBall();
		흥민손.run(12);
		현진류.walk();
		현진류.sleep();
		System.out.println(흥민손.getAge());
		System.out.println(현진류.getHeight());
		
		
		
	}
	
	public static void heightSum() {
		heightSum();
	}
	
//	private String name;
//	private int age;
//	private String gender;
//	private int weight;
//	private int height;
}
