
public class 키보드 extends 전자기기{
	private String price;
	private int keyNum;
	private String brand;
	
	//생성자
	public 키보드(String price, int keyNum, String brand) {
		super();
		// TODO Auto-generated constructor stub
		this.price = price;
		this.keyNum = keyNum;
		this.brand = brand;
	}

	//겟터셋터
	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public int getKeyNum() {
		return keyNum;
	}

	public void setKeyNum(int keyNum) {
		this.keyNum = keyNum;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	//키보드소리 함수
	public void typing() {
		System.out.println("틱틱틱틱");
	}
}
