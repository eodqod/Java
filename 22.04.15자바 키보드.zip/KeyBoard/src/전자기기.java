
public abstract class 전자기기 {
	private String voltage = "AC200V";
	
	//겟터셋터
	public String getVoltage() {
		return voltage;
	}

	public void setVoltage(String voltage) {
		this.voltage = voltage;
	}

	//전원 온오프 함수
	public void powerOn() {
		System.out.println("전원이 켜졌습니다.");
	}
	
	public void powerOff() {
		System.out.println("전원이 꺼졌습니다.");
	}
}
