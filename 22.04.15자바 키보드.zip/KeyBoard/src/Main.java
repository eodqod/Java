
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		키보드 일반키보드 = new 키보드("25,000d원", 100, "samsung");
		일반키보드.powerOn();
		System.out.println(일반키보드.getVoltage()+"입니다.");
		
		기계식키보드 백축 = new 기계식키보드("30,000원", "백축", 100, "LG");
		백축.typing();
		기계식키보드 흑축 = new 기계식키보드("30,000원", "흑축", 100, "LG");
		흑축.typing();
		흑축.ledOn();
		
		
	}

}
