
public interface Led {
	
	public void ledOn();
	public void ledOff();
	public void typing();
}
