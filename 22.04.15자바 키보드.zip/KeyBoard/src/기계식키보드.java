
public class 기계식키보드 extends 키보드 implements Led{
	
	private String ledColor;
	
	//생성자
	public 기계식키보드(String price, String ledColor, int keyNum, String brand) {
		super(price, keyNum, brand);
		this.ledColor = ledColor;
		// TODO Auto-generated constructor stub
	}

	//겟터셋터
	public String getLedColor() {
		return ledColor;
	}

	public void setLedColor(String ledColor) {
		this.ledColor = ledColor;
	}
	
	//인터페이스 오버라이드
	@Override
	public void ledOn() {
		// TODO Auto-generated method stub
		System.out.println("색이 켜졌습니다");
		
	}

	@Override
	public void ledOff() {
		// TODO Auto-generated method stub
		System.out.println("색이 꺼졌습니다");
		
	}

	@Override
	public void typing() {
		// TODO Auto-generated method stub
		switch(ledColor) {
			case("흑축"):
				System.out.println("탁탁탁탁");
				break;
			case("청축"):
				System.out.println("딱딱딱딱");
				break;
			case("적축"):
				System.out.println("턱턱턱턱");
				break;
			case("백축"):
				System.out.println("톡톡트로피카나");
				break;
		}
		
	}
	
	
	
}
