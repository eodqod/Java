package kr.human.vo;
//VO(Value Object) : 값을 저장하기 위한 용도의 클래스
//DTO(Data Transfer Object) : 값을 전달하기 위한 용도의 클래스

//클래스는 사용자 정의 자료형이다. 내가 만드는 새로운 타입이다.
//캡슐화(묶는다) : 연관성있는 데이터를 하나로 묶어서 사용한다.
//값을 저장하는 변수와 그 값을 이용하는 메소드가 합쳐져있는것이다. ==> 재사용성이 증가된다.
public class PersonVO {
	//변수라고 하지 않고 필드, 속성, 맴버변수 등으로 부른다.
	private String name;
	private int age;
	private boolean gender;
	
	public PersonVO(String name) {
		//this.name = name;
		this(name,0,false); //자신의 생성자를 호출한다.
	}
	public PersonVO(String name, int age) {
		//this.name = name;
		//this.age = age;
		this(name,age,false);
	}
	public PersonVO(String name, boolean gender) {
		//this.name = name;
		//this.gender = gender;
		this(name,0,gender);
	}
	public PersonVO(String name, int age, boolean gender) {
		this.name = name;
		this.age = age;
		this.gender = gender;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public boolean isGender() {
		return gender;
	}
	public void setGender(boolean gender) {
		this.gender = gender;
	}
	
	@Override
	public String toString() {
		return "PersonVO [name=" + name + ", age=" + age + ", gender=" + gender + "]";
	}
	
	@Override //자바 가상머신이 객체들을 구분하기 위하여 붙여주는 일련번호이다.
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + age;
		result = prime * result + (gender ? 1231 : 1237);
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PersonVO other = (PersonVO) obj;
		if (age != other.age)
			return false;
		if (gender != other.gender)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	
	
	
	//생성자 : 객체 생성시 불려지는 메소드
	//		   클래스와 이름이 같다. 메소드인데 리턴타입이 없다. 오버로딩이 가능하다. 초기화 작업 담당
	//		   모든 클래스는 한개 이상의 생성자를 꼭 가져야 한다.
	//		   사용자가 생성자를 만들지 않으면 기본생성자가 자동으로 생성된다.
	//		   하지만 다른 생성자를 만들면 기본 생성자는 만들어지지 않는다.
	//		   기본 생성자란 인수(매개변수)가 없는 생성자이다.
	
	public PersonVO() { //기본생성자 -> 밑에 생성자를 만들었기 때문에 자동으로 생기지 않고 따로 만들어야한다.
		
	}
//	
//	public PersonVO(String name, int age, boolean gender) {
//		this.name = name;
//		this.age = age;
//		this.gender = gender;
//	}
//	
//	@Override //이미 존재하는 기능을 재정의해서 사용하는것
//	public String toString() {
//		return name+"("+age+"세, "+(gender ? "남" : "여")+")";
//	}
}
