
public class Ex01 {
	public static void main(String[] args) {
		for(int i=10;i<100;i++) {
			if(solution(i)) System.out.println("고집수 : " + i);
		}
	}
	
	public static boolean solution(int n) {
		int count = 0;
		//System.out.printf("%3d : ", n);
		while(n>10) {
			n = (n/10) * (n%10);
			//System.out.printf("%3d", n);
			count++;
		}
		//System.out.println();
		return count>=4;
	}
}
