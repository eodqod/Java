
public class Ex02 {
	public static void main(String[] args) {
		// 나르시스트의 수 
		// 123 == 1*1*1 + 2*2*2 + 3*3*3 인 수 
		for(int i=100;i<1000;i++) {
			int t = (i/100)*(i/100)*(i/100);
			t += (i/10%10) *(i/10%10)*(i/10%10);
			t += (i%10) *(i%10)*(i%10);
			if(i == t) {
				System.out.println("나르시스트의 수 : " + i);
			}
		}
		// 완전수 : 자신을 제외한 약수의 합이 자신과 같은수
		for(int i=2;i<100;i++) {
			int s = 0;
			for(int j=1;j<i;j++) {
				if(i%j==0) s += j; 
			}
			if(i==s) System.out.println("완전수 : " + i);
		}
	}
}
