package kr.human.java0429;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Vector;

//List : 입력 순서가 중요할때 사용하는 자료구조이다.
public class ListEx01 {
	public static void main(String[] args) {
		Vector<String> v = new Vector<>();
		v.add("한사람");
		v.add("두사람");
		v.add("세사람");
		v.add("네사람");
		v.add("오사람");  //add는 추가, capacity는 용량, size는 개수
		System.out.println(v.capacity() + "," + v.size() + " : " + v);
		v.add("세사람");
		v.add("네사람");
		v.add("오사람");
		System.out.println(v.capacity() + "," + v.size() + " : " + v);
		v.add("세사람");
		v.add("네사람");
		v.add("오사람");
		System.out.println(v.capacity() + "," + v.size() + " : " + v); //자동으로 배열의 용량이 증가
		
		v.addElement("나인간");
		v.addElement("너인간");
		System.out.println(v.capacity() + "," + v.size() + " : " + v);
		
		v.set(0, "고친놈");
		v.setElementAt("변경인", 2); //수정
		System.out.println(v.capacity() + "," + v.size() + " : " + v);
		
		System.out.println(v.get(4));
		System.out.println(v.elementAt(4)); //가져오기 
		
		v.remove(3);
		v.remove("세사람"); //지우기
		System.out.println(v.capacity() + "," + v.size() + " : " + v);
		
		v.add(0, "추가인");
		v.add(6, "추가인2");
		System.out.println(v.capacity() + "," + v.size() + " : " + v);
		
		//반복 1
		for(int i=0; i<v.size(); i++) {
			System.out.println(v.get(i));
		}
		System.out.println("-".repeat(50));
		
		//반복2
		for(String s : v) {
			System.out.println(s);
		}
		System.out.println("-".repeat(50));
		
		//반복3
		Iterator<String> it = v.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println("-".repeat(50));
		
		//반복4
		Enumeration<String> em = v.elements();
		while(em.hasMoreElements()) {
			System.out.println(em.nextElement());
		}
		System.out.println("-".repeat(50));
		
		ListIterator<String> it2 = v.listIterator();
		System.out.println(it2.next());
		System.out.println(it2.next());
		System.out.println(it2.next());
		System.out.println(it2.previous());
		System.out.println(it2.previous());
		System.out.println(it2.previous());
		System.out.println("-".repeat(50));
		
		
		
		
		v.clear(); //값 삭제, 용량은 그대로
		System.out.println(v.capacity() + "," + v.size() + " : " + v);
		
		v.add("줄어들기");
		System.out.println(v.capacity() + "," + v.size() + " : " + v);
		
		v.trimToSize(); //용량을 사이즈만큼 줄이기
		System.out.println(v.capacity() + "," + v.size() + " : " + v);
		
		
		
		//**element가 붙은애들은 다 구버전이다.
		
	}
}
