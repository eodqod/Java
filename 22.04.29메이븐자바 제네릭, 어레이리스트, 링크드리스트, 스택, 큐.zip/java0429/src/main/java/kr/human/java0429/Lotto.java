package kr.human.java0429;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

public class Lotto {
	public static void main(String[] args) {
		Set<Integer> lotto = new HashSet<>();
		Random random = new Random();
		while (lotto.size() < 6) {
			lotto.add(random.nextInt(45) + 1);

		}
		System.out.println("자동생성된 로또번호 : " + lotto);

		Set<Integer> lotto2 = new TreeSet<>(); // TressSet은 정렬해주는 놈이다 .
		while (lotto2.size() < 6) {
			lotto2.add(random.nextInt(45) + 1);

		}
		System.out.println("자동생성된 로또번호 : " + lotto2);
	}
}
