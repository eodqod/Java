package kr.human.java0429;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class ArrayEx1 {
	public static void main(String[] args) {
		int ar1[] = {1,2,3,4,5,6};
		int ar2[][] = {{1,2},{3,4,5,6}};
		
		//1차원 배열 출력
		for(int i=0; i<ar1.length; i++) {
			System.out.printf("%3d", ar1[i]);
		}
		System.out.println();
		
		//2차원 배열 출력
		for(int i=0; i<ar2.length; i++) {
			for(int j=0; j<ar2[i].length; j++) {
				System.out.printf("%3d", ar2[i][j]);
			}
			System.out.println();
		}
		System.out.println("\n\n");
		System.out.println(Arrays.toString(ar1));
		
		System.out.println("\n\n");
		System.out.println(Arrays.deepToString(ar2));
	
		System.out.println(Arrays.binarySearch(ar1, 5));
		
		System.out.println(Arrays.compare(new int[] {1,2,3}, new int[] {1,2,3}));
		System.out.println(Arrays.compare(new int[] {1,2,3}, new int[] {1,2,4}));
		System.out.println(Arrays.compare(new int[] {1,2,3,4}, new int[] {1,2,3}));
		System.out.println(Arrays.compare(new int[] {1,2,3,4}, new int[] {1,2,3,4,5}));
		
		//배열의 값 복사
		int[] ar3 = new int[ar1.length];
		for(int i=0; i<ar1.length; i++) ar3[i] = ar1[i];
		
		System.out.println(Arrays.toString(ar1));
		System.out.println(Arrays.toString(ar3));
		System.out.println();
		
		int[] ar4 = new int[ar1.length];
		System.arraycopy(ar1, 0, ar4, 0, ar1.length);
		//			원본, 시작위치, 사본, 시작위치, 개수

		System.out.println(Arrays.toString(ar1));
		System.out.println(Arrays.toString(ar4));
		System.out.println();
		
		int[] ar5 = new int[3];
		System.arraycopy(ar1, 2, ar5, 0, 3);
		System.out.println(Arrays.toString(ar5));
		
		int[] ar6 = Arrays.copyOf(ar5, 10);
		//	ar6=복사될 배열, ar5=오리지널배열(복사할 배열), ar6의 배열 크기
		System.out.println(Arrays.toString(ar6));
		
		int[] ar7 = Arrays.copyOfRange(ar6, 2, 6);
		System.out.println(Arrays.toString(ar7));
		
		String[] names = "한사람,두사람,세사람,네사람".split(",");
		System.out.println(Arrays.toString(names));
		System.out.println();
		
		Arrays.sort(names);								//오름차순
		System.out.println(Arrays.toString(names));
		System.out.println();
		
		Arrays.sort(names, Collections.reverseOrder()); //내림차순 : 객체배열만 된다.
		System.out.println(Arrays.toString(names));
		System.out.println();
		
		//Arrays.sort(ar1, Collections.reverseOrder()); //기본 자료형은 지원되지 않는다.
		
		//Collections.reverseOrder() : 역순
		Integer[] ar8 = {1,2,3,4,5,6,7,8,9};
		Arrays.sort(ar8, Collections.reverseOrder());
		System.out.println(Arrays.toString(ar8));
		
		Integer[] ar9 = {19,27,33,46,57};
		//Comparator인터페이스는 사용자가 정렬기준을 정할 수 있다.
		Arrays.sort(ar9, new Comparator<Integer>() {

			@Override //같으면 0, 앞에것이 크면 양수, 뒤에것이 크면 음수가 되도록 구현한다.
			public int compare(Integer o1, Integer o2) {
				//return o1-o2; //오름차순
				//return o2-o1; //내림차순
				//return o1%10-o2%10; //1의자리의 오름차순
				return o2%10-o1%10; //1의자리의 내림차순
			}
		});
		System.out.println(Arrays.toString(ar9));
		
		
		
	}
}
