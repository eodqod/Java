package kr.human.java0429;

import lombok.Data;
//컴파일 시 자료형이 결정되는 것이 아니라 
//사용 시 자료형을 지정하여 사용 가능하게 한다.
//클래스를 만들어주는 클래스다.
@Data //T: Type
public class Box<T> {
	private T item;

}
