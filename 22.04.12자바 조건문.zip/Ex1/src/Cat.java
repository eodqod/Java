
public class Cat {
	private String name = "��";
	private int age = 20;
	private float weight = 5.2f;
	
	public void cry() {
		System.out.println("�߿���");
	}

	public void setWeight(float changeWeight) {
		if(changeWeight > 100 || changeWeight < 0) {
			return;
		}else {
			this.weight = changeWeight;
		}
		
	}
	
	public float getWeight() {
		return this.weight;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	
}
