
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("hello world");
		int a = 3;
		int b = 5;
		System.out.println(a+b);
		int c = 8;
		System.out.println(a*b*c);
		int bigNum1 = 2100000000;
		int bigNum2 = 47483648;
		System.out.println(bigNum1+bigNum2);
		
		boolean bool1 = true;
		boolean bool2 = false;
		if(bool1 == true) {
			System.out.println("bool1�� true");
		}
		
		char ch1 = 'h';
		if(ch1 == 'h') {
			System.out.println("h�Դϴ�.");
		}
		
		double d1 = 101.001001;
		double d2 = 202.002002;
		System.out.println(d1+d2);
		
		int i1 = (int)d1;
		int i2 = (int)d2;
		System.out.println(i1+i2);
//		������������Ÿ���� int a = 5;
//		������������Ÿ���� Cat b = new Cat();
		
		dog myDog = new dog();
		Cat myCat = new Cat();
		System.out.println(myDog.name);
		myDog.cry();
		myCat.cry();
//		myCat.weight = 50.0f;
		myCat.setWeight(50.0f);
		System.out.println(myCat.getWeight());
		myCat.setName("�ٲ۰������̸�");
		System.out.println(myCat.getName());
				
		
		
	}

}
