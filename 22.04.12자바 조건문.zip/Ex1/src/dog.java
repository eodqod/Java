
public class dog {
	String name = "�۹���";
	int age = 15;
	private float weight = 12.4f;
	
	public void cry() {
		System.out.println("�п�");
	}
	
}
