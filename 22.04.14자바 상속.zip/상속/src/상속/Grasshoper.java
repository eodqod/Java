package 상속;

public class Grasshoper extends Insects{

	public Grasshoper(String name, String color, int cm, int legNum, int wingNum) {
		super(name, color, cm, legNum, wingNum);
		// TODO Auto-generated constructor stub
	}

}
