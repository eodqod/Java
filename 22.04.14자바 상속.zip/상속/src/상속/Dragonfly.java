package 상속;

public class Dragonfly extends Insects implements Flyable{

	public Dragonfly(String name, String color, int cm, int legNum, int wingNum) {
		super(name, color, cm, legNum, wingNum);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		System.out.println("500m까지 날아오릅니다.");
		System.out.println("호버링도 가능합니다.");
	}



}
