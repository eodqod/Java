package 상속;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog ppoppi = new Dog();
		System.out.println(ppoppi.getLegNum());
		ppoppi.setName("뽀삐");
		System.out.println(ppoppi.name);
		ppoppi.bark();
		
		Wolf warwick = new Wolf();
		warwick.howling();
		
		warwick.setName("늑대");
		warwick.eat("사슴");
		
		ppoppi.eat("닭");
		
		ppoppi.move();
		warwick.move();
		
		Ant 개미1 = new Ant("antman", "black", 1, 6, 0);
		개미1.jump(15);
		
		Grasshoper 메뚜기1 = new Grasshoper("뚜기", "green", 7, 6, 2);
		메뚜기1.eat("개미");
		메뚜기1.move();
		
		Dragonfly 잠자리1 = new Dragonfly("자리", "red", 5, 6, 4);
		잠자리1.eat("메뚜기");
		잠자리1.fly();
		
		System.out.println(개미1.getName()+"입니다.");
		System.out.println(메뚜기1.getCm()+"cm");
		System.out.println(잠자리1.getWingNum()+"개");
		
		
	}

}
