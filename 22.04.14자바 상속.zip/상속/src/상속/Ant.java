package 상속;

public class Ant extends Insects{

	public Ant(String name, String color, int cm, int legNum, int wingNum) {
		super(name, color, cm, legNum, wingNum);
	}


}
