package 상속;

public class Animal {
	String name = "동물";
	int legNum;
	
	void setName(String name) {
		this.name = name;
	}
	
	String getName() {
		return name;
	}
	
	int getLegNum() {
		return legNum;
	}
	
	public void eat(String  feed) {
		System.out.println(this.name+"은 "+feed+"를 먹습니다.");
	}
	
	public void move() {
		System.out.println("이동합니다.");
	}
	
}
