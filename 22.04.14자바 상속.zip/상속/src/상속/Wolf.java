package 상속;

public class Wolf extends Animal{
	
	
	public void howling() {
		System.out.println("아우우우우우");
	}
	
	//부모에 있는 함수를 자식에서 재선언하면 오버라이드 되어서 자식의 메소드가 호출된다.
	public void move() {
		System.out.println(this.name+"가 30km/h의 속도로 이동합니다.");
	}

}
