package 상속;

public class Insects {
	private String name;
	private String color;
	private int cm;
	private int legNum = 6;
	private int wingNum = 2;

	//생성자
	public Insects(String name, String color, int cm, int legNum, int wingNum) {
		//인스턴스를 만들때 반드시 입력해야 하는 값들. 내가 조절 하면 된다. 한개든 두개든 몇개든 내가 원하는것들을 넣어서 만들면 된다.
		super();
		this.name = name;
		this.color = color;
		this.cm = cm;
		this.legNum = legNum;
		this.wingNum = wingNum;
	}
	
	//겟터셋터
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public int getCm() {
		return cm;
	}

	public void setCm(int cm) {
		this.cm = cm;
	}

	public int getLegNum() {
		return legNum;
	}

	public void setLegNum(int legNum) {
		this.legNum = legNum;
	}

	public int getWingNum() {
		return wingNum;
	}

	public void setWingNum(int wingNum) {
		this.wingNum = wingNum;
	}

	//이동,먹기,점프 함수
	public void move() {
		System.out.println(this.name+"이(가) 이동합니다.");
	}
	
	public void eat(String feed) {
		System.out.println(this.name+"은(는) "+feed+"을(를) 먹습니다.");
	}
	
	public void jump(int jumpCm) {
		System.out.printf(this.name+"이(가) %dcm만큼 점프하였습니다."+"\n",jumpCm);
	}

	
}
