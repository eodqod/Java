package 상속;

public interface Flyable {
	//인터페이스는 '약속'이다.
	//추상클래스보다 더 추상적인 개념
//	public void fly() {
//		//본문 자체가 있으면 안된다.
//	}
	public void fly(); //본문 없이 이렇게만 할 수 있다.
	
	
}
