package 상속;

public class Dog extends Animal{
	
	public void bark() {
		System.out.println("으르렁 왈왈");
	}
	
	//부모에 있는 함수를 자식에서 재선언하면 오버라이드 되어서 자식의 메소드가 호출된다.
	public void move() {
		System.out.println("20km/h의 속도로 이동합니다.");
	}

}
