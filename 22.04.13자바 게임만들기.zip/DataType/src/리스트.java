import java.util.ArrayList;

public class 리스트 {

	public static void main(String[] args) {
		ArrayList pitches = new ArrayList();
		pitches.add(100);
		pitches.add(150);
        pitches.add(200);
        pitches.add(130);
        pitches.add("110");
		
        System.out.println(pitches.get(0)); //인덱스로 값 가져온다
        
        //int speed = pitches.get(1); //Type mismatch: cannot convert from Object to int
        int speed = (int)pitches.get(1);
        
        System.out.println(pitches.size()); //리스트 안 인덱스 수
        System.out.println(pitches.contains(150)); //값이 포함되었냐(t) 아니냐(f)
        pitches.remove(0); //인덱스 지우기
        pitches.remove("110");
        System.out.println(pitches.contains(100)); //remove로 인덱스(0)을 지웠다. 그래서 (f)
        for(int index = 0; index < pitches.size(); index++) {
        	System.out.println(index+"번째 인덱스 값 = "+pitches.get(index));
        }
        
        
        
	}

}
