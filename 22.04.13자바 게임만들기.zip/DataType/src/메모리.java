//클래스는 설계도. 변수(속성)와 메소드(행동)의 모음
//데이터타입은 뭘로, 접근제한자, 리턴타입, 인자의 갯수, 이름
public class 메모리 {
	private int maxMemory = 1024*1000;  //최대용량
	private int nowMemory = 0;  //현재사용중용량
	private int price = 100000;  //가격
	private String make = "LG전자";  //제조사
	
	
	
	
	
	
	public int getMaxMemory() {
		return maxMemory;
	}

	public void setMaxMemory(int maxMemory) {
		this.maxMemory = maxMemory;
	}

	public int getNowMemory() {
		return nowMemory;
	}

	public void setNowMemory(int nowMemory) {
		this.nowMemory = nowMemory;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	//save(추가할용량)  //더이상 넣을수 없으면 알려주고, 넣을수 있으면 현재용량에 추가
	public boolean save(int addMemory) {
		if((nowMemory+addMemory)>maxMemory) {
			System.out.printf("현재용량 : %d, 추가될용량 : %d, 최대용량 : %d", nowMemory, addMemory, maxMemory);
			System.out.printf("%d만큼의 용량이 더 필요합니다.", (nowMemory+addMemory)-maxMemory);
			return false;
		}else {
			nowMemory += addMemory;
			return true;
		}
		
	}
	
	//load(뺄용량)  //뺄용량만큼 현재용량에서 빼주기. 당연히 0보다는 낮아질수 없다.
	public boolean load(int minusMemory) {
		int leftMemory = (nowMemory-minusMemory);
		if(leftMemory < 0) {
			System.out.println("불가능합니다.");
			return false;
		}else {
			nowMemory -= minusMemory;
			return true;
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
