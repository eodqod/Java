
public class 문자열 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1 = "hello world";
		String str2 = new String("this is Korea");
		
		String str3 = str1;
		str3 = "Bye world";
		System.out.println(str1);
		str3 = str2;
		str3 = "this is Sparta";
		System.out.println(str2);
		//String은 원시형 데이터타입이 아닌데 리터럴표기가
		//주소로 참조하지도 않음
		
		//내장메소드
		String name1 = "japan";
		String name2 = "JAPAN";
		String name3 = new String("japan");
		System.out.println(name1.equals(name3));
		//equals는 값을 비교하고    ==은 같은객체인지 비교한다
		
		//indexOf = 인자로 전달된 문자열의 인덱스 리턴
		System.out.println(name1.indexOf("p"));
		
		//contains = 인자로 전달된 문자열이 포함되있는지 boolean리턴
		if(name1.contains("pan")) {
			System.out.println("pan이 있습니다.");
		}
		
		//charAt = 위치에 있는 문자를 리턴
		System.out.println(name3.charAt(4));
		
		//replaceAll() 첫번째 인자를 두번째 인자로 치환. 원본 안건드림
		name3 = name3.replace("a", "i");
		System.out.println(name3);
		
		//substring 시작위치 이상, 끝위치 미만의 문자열 빼오기
		System.out.println(str3.substring(8,14));
		
		//split 특정 구분자로 문자열을 분리
		String rainbow = "빨,주,노,초,파,남,보";
		String[]arr = rainbow.split(",");
		for(int i=0; i<arr.length; i++) {
			System.out.println(arr[i]);
		}
		
		//format (degit = 숫자)
		System.out.println(String.format("나는 %d개의 피자조각을 먹을 수 있습니다. 오늘은 %d개를 먹었습니다.", 5, 3));
		String difficultSentence = String.format("나는 %d개의 피자조각을 먹을 수 있습니다. 오늘은 %d개를 먹었습니다.", 5, 3);
		System.out.println(difficultSentence);
		
		
		//printf = 포멧팅된 문자열
		System.out.printf("나는 %d개의 피자조각을 먹을 수 있습니다. 오늘은 %d개를 먹었습니다.", 5, 3);
		
		
		
		
	}

}
