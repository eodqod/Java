
public class 형변환과Final {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a = 123;
		int b = 4;
		String s = "12345";
		float f = 10.11f;
		double d = 20.22;
		
		System.out.println(a+s);  //자바에서 int와 string을 +연산하면 문자열로 자동 형변환
		System.out.println(a+f);
		System.out.println(a+d);
		System.out.println(f+d);  //부동소수점끼리의 연산은 오차발생하니 유의.
		System.out.println(s+f);  //자바에서 소수와 string을 +연산하면 문자열로 자동 형변환
		System.out.println(a/b);  //int기 때문에 몫만 나옴
		System.out.println(a/f);  //소수점까지 제대로 나옴
		System.out.println(a%b);
		int tempInt = (int)f;
		System.out.println(tempInt);  //소수를 정수로 형변환 하면 정수부만 남는다.
		double tempDouble = (double)a;
		System.out.println(tempDouble);  //정수를 소수로 형변환하면 .0을 붙여준다.
		float tempFloat = (float)b;
		System.out.println(tempFloat);  //정수를 소수로 형변환하면 .0을 붙여준다.
		System.out.println(tempDouble==123.0);  //true
		
		
		final int finalInt = 1234;
		//finalInt = finalInt + 4321; final은 재할당 안된다.
		final double PI = 3.14159265358979;

	}

}
