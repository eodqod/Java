import java.util.HashMap;

//대응관계를 쉽게 표현할 수 있게 해 주는 자료형
public class 맵 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    HashMap<String, String> map = new HashMap<>(); //제네릭
        map.put("people", "사람");
        map.put("baseball", "야구");
        map.put("lion", "사자");
        map.put("tiger", "호랑이");
        
        System.out.println(map.get("people"));
        System.out.println(map.containsKey("lion")); //key가 첫번째
        System.out.println(map.containsValue("사자")); //value가 두번째
	}

}
