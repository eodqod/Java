
public class 배열 {

	public static void main(String[] args) {
		
		//배열 만드는법
		//1. 데이터타입[] 이름 = {데이터1, 데이터2, 데이터3}
		//2. 데이터타입 이름[] = {데이터1, 데이터2, 데이터3}
		//3. 데이터타입[] 이름 = new 데이터타입[크기];
		String[] weeks = {"월", "화", "수", "목", "금", "토", "일"};
		
		//중요
		//1. 크기가 고정되어있다. 처음의 크기에서 변할 수 없다.
		//2. 데이터타입이 모두 통일되어야 한다.
		System.out.println(weeks[2]);
		System.out.println(weeks); //저장된 메모리의 주소가 나온다. @71dac704
		
		//향상된 for문
//		for (타입 변수명 : 반복가능한 객체) {
//			본문
//		}
		for (String elem : weeks) {
			System.out.println(elem);
		}
		
		//2차원 배열
		String[][] arr = {{"1-1", "1-2", "1-3", "1-4", "1-5"},{"2-1", "2-2", "2-3", "2-4", "2-5"}};
		for(String[] oneDemen : arr) {
			System.out.println();
			for(String element : oneDemen) {
				System.out.print(element + ", ");
			}
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
