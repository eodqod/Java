package 객체;

public class monster {
	private String name;
	private int hp;
	private weapon equipment;
	private int damage;
	

	
	public monster(String name, int hp, weapon equipment, int damage) {
		super();
		this.name = name;
		this.hp = hp;
		this.equipment = equipment;
		this.damage = damage;
	}

	public void attack() {
		
	}

	public boolean sleep() {
		if(hp <= 500) {
			hp = hp+100;
			return true;
		}else {
			return false;
		}
	}
	
	public void skill() {
		
	}
}
