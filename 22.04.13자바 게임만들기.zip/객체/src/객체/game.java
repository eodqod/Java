package 객체;

public class game {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		player userId = new player("java", 500, null, 50);
		
	}

}
