package 객체;

public class weapon {
	private String name;
	private String type;
	private int damage;
	
	
	public weapon(String name, String type, int damage) {
		super();
		// TODO Auto-generated constructor stub
		this.name = name;
		this.type = type;
		this.damage = 50;
	}
	
	
}
