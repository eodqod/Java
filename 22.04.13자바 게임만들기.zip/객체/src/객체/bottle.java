package 객체;

public class bottle {
	private int maxMilliliter = 2000;//최대용량
	private int nowMilliliter = 0;//현재용량
	
	
	
	
	
	public boolean putIn(int addMilliliter){//추가로 넣을 용량
		if((nowMilliliter+addMilliliter)>maxMilliliter) {
			System.out.println("bottle에 "+addMilliliter+"만큼의 용량을 추가 할 수 없습니다.");
			return false;
		}else {
			nowMilliliter += addMilliliter;
			System.out.println("bottle에 "+addMilliliter+"의 용량이 추가되었습니다. 현재 용량은 "+nowMilliliter+"입니다.");
			return true;
		}
	}
	
	public boolean drain(int minusMilliliter){//뺄용량
		if((nowMilliliter-minusMilliliter)<0) {
			System.out.println("bottle에 "+minusMilliliter+"만큼의 용량을 뺄 수 없습니다.");
			return false;
		}else {
			nowMilliliter -= minusMilliliter;
			System.out.println("bottle에 "+minusMilliliter+"의 용량이 빠졌습니다. 현재 용량은 "+nowMilliliter+"입니다.");
			return true;
		}
	}
	public boolean calcLeft(){//남은용량 계산
		int leftMilliliter = maxMilliliter-nowMilliliter;
		if(leftMilliliter>0) {
			System.out.println("남은 용량은 "+leftMilliliter+"입니다.");
			return true;
		}else {
			System.out.println("남은 용량이 없습니다.");
			return false;
		}
		
	}

	public void empty(){//현재용량 다 비우기
		nowMilliliter=0;
	}
	
	
	
	
	
	
	
	
}