//1. player 클래스 정의
//	name이름, hp체력, equipment무기, damage공격력, attack(일반공격), sleep(잠자기, 체력회복), skill(기술)
//	
//2.monster 클래스 정의
//	이름, 체력, 무기, 공격력, attack, sleep, skill
//	
//3. weapon 클래스 정의
//	이름, 종류, 플러스공격력
//	
//4.game클래스에는 main함수 있음.
//	main함수에서 10회의 전투 후 체력이 많거나 살아남은 사람이 이기는 턴제게임을 만들어보세요.
//	
//<개념>
//1. 클래스생성
//2. 클래스안의 메소드 생성
//3. 접근제한자
//4. 클래스정의와 인스턴스 호출을 구분 할 줄 알아야함. 함수호출과 정의 마찬가지
//5. 메소드안에서는 연산 후 결과 리턴
//6. 논리적이고 재미있는 게임의 흐름 생각
//7. 키보드 입력
//		Scanner sc = new Scanner(System.in); //System.out의 반대. 키보드로부터 입력받음
//		String myName = sc.nextLine(); //한줄을 입력받는 함수 호출