
public class 프로그래머스연습 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		solution("ab", 4);
	}
	public static String solution(String s, int n) {
        String answer = "";
        char[] alpha = s.toCharArray();
        for (int i=0; i<alpha.length; i++){
	         String str = String.valueOf(alpha[i]+=n);
	         System.out.print(str);
	         
	     }
        return answer;
    }

}
