
public class 가변배열 {
	public static void main(String[] args) {
		//자바의 배열은 가변배열이다.
		//가변배열 : 열의 개수가 다를 수 있다. 동적배열이기 때문
		//동적배열 : 선언 시 크기가 결정되는것이 아니라 실행 시 결정되는것
		
		int ar[][] = new int[5][]; //일단 행만 확보
		for(int i=0; i<ar.length; i++) {
			ar[i] = new int[(i+1)*2];
		}
		arrayPrint(ar);
	}
	public static void arrayPrint(int ar[][]) {
		for (int i = 0; i < ar.length; i++) {
			for (int j = 0; j < ar[i].length; j++) {
				System.out.printf("%3d", ar[i][j]);
			}
			System.out.println();
		}
		System.out.println("-".repeat(27) + "\n");
	}

}