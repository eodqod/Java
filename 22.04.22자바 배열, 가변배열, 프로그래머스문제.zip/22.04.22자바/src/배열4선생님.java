/*
// 문제 : 5행 5열짜리 정수 배열을 만들어 아래처럼 채우고 출력하시오
/*
	빗살무늬 채우기

	  1  3  6 10 15
	  2  5  9 14 19
	  4  8 13 18 22
	  7 12 17 21 24
	 11 16 20 23 25
  */
public class 배열4선생님 {
	final static int MAX = 5; // 상수 선언. 왜? 작게 만들어 나중에 크게 적용시킨다. 확장성 고려해야 함!!!

	public static void main(String[] args) {
		int ar[][] = new int[MAX][MAX];
		int k=0;
		for (int i = 0; i < ar.length; i++) {
			for (int j = 0; j <= i; j++) {
				ar[i-j][j] = ++k;
			}
		}
		/* 채워지는 순서를 보면 규칙이 나온다. 앞의 숫자는 줄어들고 뒤의 숫자는 늘어난다.
		 * [0][0]
		 * [1][0], [0][1]
		 * [2][0], [1][1], [0][2]
		 * [3][0], [2][1], [1][2], [0][3]
		 * [4][0], [3][1], [2][2], [1][3], [0][4]
		 */
		arrayPrint(ar);
		for (int i = 1; i < ar.length; i++) {
			for (int j = i; j <MAX ; j++) {
				ar[MAX-1+i-j ][j] = ++k;
			}
		}
		/* 채워지는 순서를 보면 규칙이 나온다. 앞의 숫자는 줄어들고 뒤의 숫자는 늘어난다.
		 * [4][1],[3][2],[2][3],[1][4]
		 * [4][2],[3][3],[2][4]
		 * [4][3],[3][4]
		 * [4][4]
		 */
		arrayPrint(ar);
		
	}

	// 2차원 배열 출력하는 메서드
	public static void arrayPrint(int ar[][]) {
		for (int i = 0; i < ar.length; i++) {
			for (int j = 0; j < ar[i].length; j++) {
				System.out.printf("%3d", ar[i][j]);
			}
			System.out.println();
		}
		System.out.println("-".repeat(27) + "\n");
	}
}
