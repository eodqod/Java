import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.Test;

public class 테스트 {
	
	// 테스트에 사용되는 메소드는 public void 이어야 한다.
	
	public static int add(int a, int b) {
		return a+b;
	}
	
	@Test
	public void addTest() {
		assertEquals(add(2,3), 5);
		assertNotEquals(add(2,3), 3);
	}
}
