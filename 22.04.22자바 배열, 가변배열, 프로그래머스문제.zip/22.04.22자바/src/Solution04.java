import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class Solution04 {

	class Solution {
		// 에라토스테네스의 체 알고리즘
		public int solution(int n) {
			int answer = 0;
			int ar[] = new int[n + 1]; // 크기보다 1 크게 배열 선언
			for (int i = 2; i < ar.length; i++) {
				// 이미 체크된 수의 배수들은 합성수
				if (ar[i] == 1)
					continue;
				// i를 제외한 i의 배수들을 1로 체크
				for (int j = i + i; j < ar.length; j += i)
					ar[j] = 1;
			}
			for (int i = 2; i < ar.length; i++) {
				if (ar[i] != 1) { // 1이아닌(배수가 아닌) 갯수
					answer++;
					// System.out.printf("%4d", i);
				}
			}
			// System.out.println();
			return answer;
		}
	}

	@Test
	public void test() {
		assertEquals(new Solution().solution(10), 4);
		assertEquals(new Solution().solution(5), 3);
	}

}
