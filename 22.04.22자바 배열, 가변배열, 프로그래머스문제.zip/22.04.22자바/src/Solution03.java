import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class Solution03 {
	
	class Solution {
		public String solution(String s, int n) {
			String answer = "";
			for(char ch : s.toCharArray()) {
				if(ch==' ') {
					answer += ch;
				}else if(ch>='a'&& ch<='z'){
					answer += (char)('a' + (ch+n-'a')%26);
				}else {
					answer += (char)('A' + (ch+n-'A')%26);
				}
			}
			System.out.println(answer);
			return answer;
		}
	}
	
	@Test
	public void test() {
		assertEquals(new Solution().solution("AB",1), "BC");
		assertEquals(new Solution().solution("z",1), "a");
		assertEquals(new Solution().solution("aBz",4), "eFd");
	}
	
}
