
public class 프로그래머스문제선생님 {
	//문자열 정수로 바꾸기
	class Solution {
		public int solution(String s) {
			return Integer.parseInt(s);
		}
	}
	//수박수박수박수...
	class Solution2 {
		public String solution(int n) {
			String answer = "";
			for(int i=0;i<n;i++) answer +=  "수박".charAt(i%2);
			return answer;
		}
	}
	//시저암호
	class Solution3 {
		public String solution(String s, int n) {
			String answer = "";
			for(char ch : s.toCharArray()) {
				if(ch==' ') {
					answer += ch;
				}else if(ch>='a'&& ch<='z'){
					answer += (char)('a' + (ch+n-'a')%26);
				}else {
					answer += (char)('A' + (ch+n-'A')%26);
				}
			}
			System.out.println(answer);
			return answer;
		}
	}
	//소수찾기
	class Solution4 {
		// 에라토스테네스의 체 알고리즘
		public int solution(int n) {
			int answer = 0;
			int ar[] = new int[n + 1]; // 크기보다 1 크게 배열 선언
			for (int i = 2; i < ar.length; i++) {
				// 이미 체크된 수의 배수들은 합성수
				if (ar[i] == 1)
					continue;
				// i를 제외한 i의 배수들을 1로 체크
				for (int j = i + i; j < ar.length; j += i)
					ar[j] = 1;
			}
			for (int i = 2; i < ar.length; i++) {
				if (ar[i] != 1) { // 1이아닌(배수가 아닌) 갯수
					answer++;
					// System.out.printf("%4d", i);
				}
			}
			// System.out.println();
			return answer;
		}
	}
}
