/*
// 문제 : 배열을 모래시계처럼 채워 출력하시오
/*
  1  2  3  4  5  6  7
     8  9 10 11 12   
       13 14 15      
          16         
       17 18 19      
    20 21 22 23 24   
 25 26 27 28 29 30 31
*/

public class 배열2선생님 {
	final static int MAX = 7; // 상수 선언. 왜? 작게 만들어 나중에 크게 적용시킨다. 확장성 고려해야 함!!!
	
	public static void main(String[] args) {
		int ar[][] = new int[MAX][MAX];
		int k=0;
		for(int i=0;i<=MAX/2;i++) {
			for(int j=i;j<MAX-i;j++) { // 시작값은 늘어나고 종료값은 줄어든다.
				ar[i][j] = ++k;
			}
		}
		arrayPrint(ar);
		for(int i=MAX/2+1;i<MAX;i++) {
			for(int j=MAX-i-1;j<=i;j++) { // 시작값은 줄어들고 종료값은 늘어난다.
				ar[i][j] = ++k;
			}
		}
		arrayPrint(ar);
	}

	// 2차원 배열 출력하는 메서드
	public static void arrayPrint(int ar[][]) {
		for (int i = 0; i < ar.length; i++) {
			for (int j = 0; j < ar[i].length; j++) {
				if(ar[i][j]!=0)
					System.out.printf("%3d", ar[i][j]);
				else
					System.out.print("   ");// 0인 경우는 공백 출력
			}
			System.out.println();
		}
		System.out.println("-".repeat(27) + "\n");
	}
}
