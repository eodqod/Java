import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class 백준배열문제 {

	public static void main(String[] args) {
		// 
		
	}
	
	public static double getAvg(int cnt, int[] data) {
		int max = data[0];
		for(int i=1; i<cnt; i++) {
			if(max<data[i]) {
				max = data[i];
			}
		}                              // 배열 안 최대값 구하기
		
		double sum = 0.0;
		for(int i=0; i<cnt; i++) {
			sum += (double)data[i]/max*100;
			// System.out.println((double)data[i]/max*100);
		}
		// System.out.println(sum/cnt);
		return sum/cnt;
	}
	
	@Test
	public void test() {
		assertEquals(getAvg(3, new int[] {40,80,60}), 75.0, 0.0);
		assertEquals(getAvg(3, new int[] {10,20,30}), 66.66666666666667, 0.0);
		assertEquals(getAvg(4, new int[] {1,100,100,100}), 75.25, 0.0);
		assertEquals(getAvg(5, new int[] {1,2,4,8,16}), 38.75, 0.0);
		assertEquals(getAvg(2, new int[] {3, 10}), 65.0, 0.0);
		assertEquals(getAvg(4, new int[] {10, 20, 0, 100}), 32.5, 0.0);
		assertEquals(getAvg(1, new int[] {50}), 100.0, 0.0);
		assertEquals(getAvg(9, new int[] {10,20,30,40,50,60,70,80,90}), 55.55555555555556, 0.0);
	}
}
