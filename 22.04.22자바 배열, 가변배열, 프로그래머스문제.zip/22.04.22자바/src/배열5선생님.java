// 문제 : 배열을 달팽이로 채우기
/*
  1  2  3  4  5
 16 17 18 19  6
 15 24 25 20  7
 14 23 22 21  8
 13 12 11 10  9
  */
public class 배열5선생님 {
	final static int MAX = 5; // 상수 선언. 왜? 작게 만들어 나중에 크게 적용시킨다. 확장성 고려해야 함!!!

	public static void main(String[] args) {
		int ar[][] = new int[MAX][MAX];
		int k=0; // 증가변수
		int sw = 1, row=0, col = -1, count = MAX; // 반전, 행, 열. 개수
		while(true) {
			// 열 증감
			for(int i=0;i<count;i++) {
				col += sw;
				ar[row][col] = ++k;
			}
			if(--count==0) break; // 개수 감소 0이면 종료
			// 행증감
			for(int i=0;i<count;i++) {
				row += sw;
				ar[row][col] = ++k;
			}
			sw *= -1; // 반전
		}

		arrayPrint(ar);
		
	}

	// 2차원 배열 출력하는 메서드
	public static void arrayPrint(int ar[][]) {
		for (int i = 0; i < ar.length; i++) {
			for (int j = 0; j < ar[i].length; j++) {
				System.out.printf("%3d", ar[i][j]);
			}
			System.out.println();
		}
		System.out.println("-".repeat(27) + "\n");
	}
}
