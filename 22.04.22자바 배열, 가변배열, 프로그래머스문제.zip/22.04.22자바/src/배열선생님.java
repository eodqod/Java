/*
// 문제 : 3행 3열짜리 정수 배열을 만들어  지그재그로 채워 출력하시오
/*
  1  2  3
  6  5  4
  7  8  9

  1  6  7
  2  5  8
  3  4  9
*/

public class 배열선생님 {
	final static int MAX = 10; // 상수 선언. 왜? 작게 만들어 나중에 크게 적용시킨다. 확장성 고려해야 함!!!
	
	public static void main(String[] args) {
		int ar[][] = new int[MAX][MAX];
		
		for(int i=0;i<ar.length;i++) {
			for(int j=0;j<ar[i].length;j++) {
				// 고정값에 늘어나는 숫자를 더하면 늘어나고
				// 고정값에 늘어나는 숫자를 빼주면 즐어든다.  시작값을 만드는것이 문제의 해결방법이다.
				 ar[i][j] = (i%2==0) ? i * MAX + j + 1 : (i+1)*MAX-j; // 첫번째 답
				//ar[j][i] = (i%2==0) ? i * MAX + j + 1 : (i+1)*MAX-j;    // 두번째 답
			}
		}
		arrayPrint(ar);
	}
	// 2차원 배열 출력하는 메서드
	public static void arrayPrint(int ar[][]) {
		for(int i=0;i<ar.length;i++) {
			for(int j=0;j<ar[i].length;j++) {
				System.out.printf("%3d", ar[i][j]);
			}
			System.out.println();
		}
		System.out.println("-".repeat(27) + "\n");
	}
}
