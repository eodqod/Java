import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class Solution02 {
	
	class Solution {
		public String solution(int n) {
			String answer = "";
			for(int i=0;i<n;i++) answer +=  "수박".charAt(i%2);
			return answer;
		}
	}
	
	@Test
	public void test() {
		assertEquals(new Solution().solution(3), "수박수");
		assertEquals(new Solution().solution(4), "수박수박");
	}
	
}
