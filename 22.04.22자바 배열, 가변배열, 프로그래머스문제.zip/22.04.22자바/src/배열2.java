// 문제 : 배열을 모래시계처럼 채워 출력하시오
/*
  1  2  3  4  5  6  7
     8  9 10 11 12   
       13 14 15      
          16         
       17 18 19      
    20 21 22 23 24   
 25 26 27 28 29 30 31
*/

public class 배열2 {
	final static int max = 7;
	public static void main(String[] args) {
		int ar[][] = new int[max][max];
		
		
	}
}
