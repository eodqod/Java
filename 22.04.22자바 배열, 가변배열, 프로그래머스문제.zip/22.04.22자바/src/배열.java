// 문제 : 3행 3열짜리 정수 배열을 만들어  지그재그로 채워 출력하시오
/*
  1  2  3
  6  5  4
  7  8  9

  1  6  7
  2  5  8
  3  4  9
*/

public class 배열 {
	public static void main(String[] args) {
		int max = 3;
		int ar[][] = new int[max][max];
		
		for(int i=0; i<ar.length; i++) {
			for(int j=0; j<ar[i].length; j++) {
				
			}
			
		}
		
	}
}
