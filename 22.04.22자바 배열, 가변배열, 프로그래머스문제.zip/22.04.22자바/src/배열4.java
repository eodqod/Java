//문제 : 5행 5열짜리 정수 배열을 만들어 아래처럼 채우고 출력하시오
/*
1  3  6 10 15
2  5  9 14 19
4  8 13 18 22
7 12 17 21 24
11 16 20 23 25
*/
public class 배열4 {
	final static int MAX = 5; // 상수 선언. 왜? 작게 만들어 나중에 크게 적용시킨다. 확장성 고려해야 함!!!
	
	public static void main(String[] args) {
		int ar[][] = new int[MAX][MAX];
		int k=0;
		for(int i=0; i<ar.length; i++) {
			for(int j=0; j<=i; j++) {
				ar[i-j][j] = ++k;
			}
		}
		for(int i=1; i<ar.length; i++) {
			for(int j=i; j<MAX; j++) {
				ar[MAX-1+i-j][j] = ++k;
			}
		}
		arrayPrint(ar);
	}
	
	// 2차원 배열 출력하는 메서드
	public static void arrayPrint(int ar[][]) {
		for (int i = 0; i < ar.length; i++) {
			for (int j = 0; j < ar[i].length; j++) {
				if (ar[i][j] != 0)
					System.out.printf("%3d", ar[i][j]);
				else
					System.out.print("   ");// 0인 경우는 공백 출력
			}
			System.out.println();
		}
		System.out.println("-".repeat(27) + "\n");
	}
}
