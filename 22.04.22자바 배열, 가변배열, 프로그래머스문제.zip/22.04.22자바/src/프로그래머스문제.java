import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.Test;

public class 프로그래머스문제 {
	public static void main(String[] args) {
		
	}
	//소수찾기
	public static int solution(int n) {
        int answer = 0;
        int [] number = new int[n+1];
        
        for(int i=2; i<=n; i++) {
        	number[i] = i;
        }
        
        for(int i=2; i<n; i++) {
        	if(number[i]==0) {
        		continue;
       		}
        	for(int j= 2*i; j<=n; j+=i) {
        		number[j] = 0;
        	}
       	}
        for(int i=0; i<number.length; i++) {
        	if(number[i]!=0) answer++;
        }
       	return answer;
       	
    }
	//수박수박수박수...
	public String solution2(int n) {
        String answer = "";
        String su = "수";
        String bak = "박";
        for(int i=1; i<=n; i++) {
        	if(i%2!=0) {
        		answer += su;
        	}else {
        		answer += bak;
        	}
        }
        return answer;
    }
	// 문자열 정수로 바꾸기
	public int solution(String s) {
        int answer = 0;
        return answer = Integer.parseInt(s);
    }
	//시저암호
	public String solution(String s, int n) {
        String answer = "";
        char[] alpha = s.toCharArray();
        for (int i=0; i<alpha.length; i++){
	         System.out.print(alpha[i]+=n);
	     }
        return answer;
    }

	@Test
	public void solutionTest() {
		assertEquals(solution("a b z"), "e f d");
	}
}
