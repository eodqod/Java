import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class Solution01 {
	
	class Solution {
		public int solution(String s) {
			return Integer.parseInt(s);
		}
	}
	
	@Test
	public void test() {
		assertEquals(new Solution().solution("1234"), 1234);
		assertEquals(new Solution().solution("-1234"), -1234);
	}
	
}
