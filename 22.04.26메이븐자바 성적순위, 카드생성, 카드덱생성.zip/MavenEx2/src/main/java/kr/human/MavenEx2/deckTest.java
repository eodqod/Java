package kr.human.MavenEx2;

public class deckTest {

	public static void main(String[] args) {
		Deck deck = new Deck(); //카드 1묶음 섞여서 만들어진다.
		for(int i=0; i<10; i++) System.out.print(deck.nextCard()+" "); //10장만 가져와보기
		System.out.println();
		for(int i=0; i<10; i++) System.out.print(deck.nextCard()+" "); //10장만 가져와보기
		System.out.println();
		for(int i=0; i<10; i++) System.out.print(deck.nextCard()+" "); //10장만 가져와보기
		System.out.println();
		for(int i=0; i<10; i++) System.out.print(deck.nextCard()+" "); //10장만 가져와보기
		System.out.println();
		for(int i=0; i<10; i++) System.out.print(deck.nextCard()+" "); //10장만 가져와보기
		System.out.println();
		for(int i=0; i<10; i++) {
			CardVO cardVO = deck.nextCard();
			if(cardVO!=null) {
				System.out.print(cardVO+" "); //10장만 가져와보기	
			}else {
				System.out.println("더 이상 카드가 없습니다.");
				break;
			}
			
		}
		System.out.println();
		
	}

}
