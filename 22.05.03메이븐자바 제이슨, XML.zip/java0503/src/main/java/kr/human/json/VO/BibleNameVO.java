package kr.human.json.VO;

import lombok.Data;

@Data
public class BibleNameVO {
	private int i;
	private String k;
	private String e;
	private String y;
	
}
