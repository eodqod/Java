package kr.human.json.VO;

import java.util.List;

import lombok.Data;

@Data
public class ItemVO {
	private String id;
	private String name;
	private List<History> history;
	//리스트로 만들어도 읽는다 !! 
	
	@Data
	public static class History{
		private String date;
		private String item;
		
	}
	
}
