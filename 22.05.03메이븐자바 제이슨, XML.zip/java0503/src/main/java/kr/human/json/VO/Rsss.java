package kr.human.json.VO;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Data
@XmlRootElement(name = "rss")
public class Rsss {
	private Channel channel;
	
	@ToString
	@EqualsAndHashCode
	@Getter
	@Setter
	@XmlRootElement
	@XmlType(propOrder = {"title","link","description","language","generator","pubDate","item"})
	public static class Channel{
		private String title;
		private String link;
		private String description;
		private String language;
		private String generator;
		private String pubDate;
		private List<Item> item;
		
	}
	
	@ToString
	@EqualsAndHashCode
	@Getter
	@Setter
	@XmlRootElement
	@XmlType(propOrder = {"author","category","title","link","guid","description"})
	public static class Item{
		private String author;
		private String category;
		private String title;
		private String link;
		private String guid;
		private List<Description> description;
	}
	
	@ToString
	@EqualsAndHashCode
	@Getter
	@Setter
	@XmlRootElement
	@XmlType(propOrder = {"header","body"})
	public static class Description{
		private List<Header> header;
		private List<Body> body;
	}
	
	@ToString
	@EqualsAndHashCode
	@Getter
	@Setter
	@XmlRootElement
	@XmlType(propOrder = {"tm","ts","x","y"})
	public static class Header{
		private String tm;
		private String ts;
		private String x;
		private String y;
	}
	
	@ToString
	@EqualsAndHashCode
	@Getter
	@Setter
	@XmlRootElement
	public static class Body{
		private List<Data> data; 
	}
	
	@ToString
	@EqualsAndHashCode
	@Getter
	@Setter
	@XmlRootElement
	@XmlType(propOrder = {"hour","wfKor","wfEn","wdKor"})
	public static class Data{
		private int hour;
		private String wfKor;
		private String wfEn;
		private String wdKor;
	}
	
}
