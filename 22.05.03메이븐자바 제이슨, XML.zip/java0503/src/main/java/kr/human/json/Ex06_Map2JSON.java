package kr.human.json;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import kr.human.json.VO.BibleNameVO;

//JSON형식의 파일 저장/읽기
public class Ex06_Map2JSON {
	public static void main(String[] args) {
		Gson gson = new Gson();
		
		//JSON파일을 자바 Map객체로 읽기
		try(FileReader fr = new FileReader("src/main/resources/bible_name.json")){
			@SuppressWarnings("unchecked") // 경고무시
			Map<String, Object>[] mapArray = gson.fromJson(fr, Map[].class);
			for(Map<String, Object> map : mapArray) {
				System.out.println(map);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("-".repeat(50));
		
		//JSON파일을 자바 vo객체로 읽기
		try(FileReader fr = new FileReader("src/main/resources/bible_name.json")){
			BibleNameVO[] voArray = gson.fromJson(fr, BibleNameVO[].class);
			for(BibleNameVO vo : voArray) {
				System.out.println(vo.getK()+"("+vo.getE()+")");
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("-".repeat(50));
		
		//JSON파일을 자바 vo객체로 읽기
		try(FileReader fr = new FileReader("src/main/resources/bible_name.json")){
			JsonArray jsonArray = gson.fromJson(fr, JsonArray.class);
			System.out.println(jsonArray.size()+"개");
			for(JsonElement e : jsonArray) { //배열 반복
				//System.out.println(e);
				JsonObject obj = (JsonObject)e; //형변환 하여 값을 뽑아야 한다.
				System.out.println(obj.get("k").getAsString());
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}
