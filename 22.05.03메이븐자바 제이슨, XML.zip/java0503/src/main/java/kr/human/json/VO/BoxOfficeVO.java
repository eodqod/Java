package kr.human.json.VO;

import lombok.Data;

@Data
public class BoxOfficeVO {
	private BoxOfficeResult boxOfficeResult;
	
	@Data
	public static class BoxOfficeResult{
		private String boxofficeType;
		private String showRange;
		private DailyBoxOfficeList[] dailyBoxOfficeList;
	}
	
	@Data
	public static class DailyBoxOfficeList{
		private String rank;	//순위
		private String movieNm; //영화이름
		private String openDt;  //개봉일
	}
}
