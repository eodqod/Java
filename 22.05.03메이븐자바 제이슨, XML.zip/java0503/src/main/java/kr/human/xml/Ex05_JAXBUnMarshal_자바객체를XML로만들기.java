package kr.human.xml;

import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import kr.human.json.VO.Rsss;

public class Ex05_JAXBUnMarshal_자바객체를XML로만들기 {
	public static void main(String[] args) {
		
		try(FileWriter fw = new FileWriter("src/main/resources/rss2.xml")) {
			URL url = new URL("http://www.kma.go.kr/wid/queryDFSRSS.jsp?zone=4111573000");
			//1. JAXB context객체 생성 : 클래스타입을 인수로 지정
			JAXBContext context = JAXBContext.newInstance(Rsss.class);
			
			//2. 자바객체를 XML로 변경하는 객체 생성
			Marshaller m = context.createMarshaller();
			Unmarshaller um = context.createUnmarshaller();
			
			//3. XML의 모양지정
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			
			//URL에서 읽기
			InputStreamReader isrr = new InputStreamReader(url.openStream());
			Rsss rsss = (Rsss) um.unmarshal(isrr);
			
			//제목 출력
			System.out.println(rsss.getChannel().getTitle());
			System.out.println(rsss.getChannel().getLink());
			System.out.println(rsss.getChannel().getPubDate());
			//기사출력
			for(Rsss.Item item : rsss.getChannel().getItem()) {
				System.out.println(item.getTitle() + " : " + item.getLink());
			}
			//XML파일로 저장
			m.marshal(rsss, fw);
			
		} catch (JAXBException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
}
