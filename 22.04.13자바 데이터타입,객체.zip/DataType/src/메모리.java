
public class 메모리 {
	private int maxSize = 1024*1000;	//최대용량
	private int prsentSize = 0;			//현재 사용중인 용량
	private int price = 200000;			//가격
	private String maker = "samsung";	//제조사
	
	
	
	
	
	public int getMaxSize() {
		return maxSize;
	}

	public void setMaxSize(int maxSize) {
		this.maxSize = maxSize;
	}

	public int getPrsentSize() {
		return prsentSize;
	}

	public void setPrsentSize(int prsentSize) {
		this.prsentSize = prsentSize;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	//인자로 받은 용량만큼 현재용량에 저장
	public boolean save(int addSize) {
		if((prsentSize + addSize)>maxSize) {
			System.out.printf("현재용량 : %d, 추가용량 : %d, 최대용량 : %d\n", prsentSize,addSize,maxSize);
			System.out.printf("%d만큼의 용량이 더 필요합니다.", (prsentSize+addSize)-maxSize);
			//현재용량 40, 추가용량 80, 최대용량 100이면 20만큼 더 필요
			return false;
		}else {
			prsentSize += addSize;
			System.out.println(addSize+"가 저장되어 현재용량 : "+prsentSize);
			return true;
		}
	}
	
	//인자로 받은 용량만큼 빼짐
	public boolean load(int minusSize) {
		int leftSize = prsentSize - minusSize;
		if(leftSize <0) {
			System.out.println("불가능합니다");
			return false;
		}else {
			prsentSize-=minusSize;
			System.out.println(minusSize+"만큼 용량이 확보되어 현재용량 : "+prsentSize);
			return true;
		}
	}

	
}
