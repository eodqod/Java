//서로 관련이 있는 여러 개의 상수 집합을 정의할 때 사용하는 자료형
public class Enum {
	//생성문법   :    enum 열거체 이름 {상수1, 상수2, ...}
	enum CoffeeType {
	    AMERICANO,
	    ICE_AMERICANO,
	    CAFE_LATTE
	};
	
	//향상된 for문  for(자료형 이름 : 반복가능한자료)
	public static void main(String[] args) {
		
       for(CoffeeType type: CoffeeType.values()) {
            System.out.println(type); 
        }
        
	}
	
}
