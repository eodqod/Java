
public class 형변환과final {
	public static void main(String[] args) {
		
		int a = 123;
		int b = 4;
		String s = "12345";
		float f = 10.11f;
		double d = 20.22;
		
		System.out.println(a+s);  //int 와 String을 + 연산하면 문자열로 변환
		System.out.println(a+f);
		System.out.println(a+d);
		System.out.println(f+d);  //실수끼리의 연산은 오차 발생 가능
		System.out.println(s+f);  //문자열과 실수를 더하면 문자열로 변환
		System.out.println(a/b);	//  int/int는 결과가 int
		System.out.println(a/f);	//  소수/소수는 소수점까지 결과
		System.out.println(a%b);
		int tempInt = (int)f;
		System.out.println(tempInt);	//소수를 정수로 바꾸면 정수부만 리턴
		double tempDouble = (double)a;
		System.out.println(tempDouble);	//정수를 소수로 바꾸면 깔끔하게 .0붙음
		System.out.println(tempDouble==123.0);  //true
		
		
		final int fianlInt = 12345;
		//fianlInt = fianlInt + 4321;   
		final double PI = 3.14159265358979;
		 
	}
}
