import java.util.HashMap;

// 사전형태의 자료구조.  키와 밸류로 저장
public class 맵 {
	public static void main(String[] args) {
        HashMap<String, String> map = new HashMap<>();	
        map.put("people", "사람");
        map.put("baseball", "야구");
        map.put("lion", "사자");
        map.put("tiger", "호랑이");
        
        
        System.out.println(map.get("people"));	//key를 통해 value를 가져옴
        System.out.println(map.containsKey("lion"));
        System.out.println(map.containsValue("사자"));
	}
}
