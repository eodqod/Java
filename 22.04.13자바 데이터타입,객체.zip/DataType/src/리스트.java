import java.util.ArrayList;
import java.util.Arrays;

public class 리스트 {
	public static void main(String[] args) {
		ArrayList pitches = new ArrayList();
        pitches.add(100);
        pitches.add(150);
        pitches.add(200);
        pitches.add(130);
        pitches.add("110");
        
        System.out.println(pitches.get(1));	//인덱스로 값 가져오기
        
        //int speed = pitches.get(1);	//Type mismatch: cannot convert from Object to int
        int speed = (int)pitches.get(1);	
        
        System.out.println(pitches.size());	//현재 가지고있는 요소의 크기
        System.out.println(pitches.contains(160));	//값이 포함되어있는지 확인
        
        //0번째 지워서 없어짐
        pitches.remove(0);	//인자가 숫자면 인덱스로 제거
        pitches.remove("110");	//인자가 숫자가 아니면 값으로 제거
        System.out.println(pitches.contains(100));
        for (int index = 0; index < pitches.size(); index++) {
        	   System.out.println(index+"번째 인덱스 값 : "+pitches.get(index));
    	 }


	}

}
