
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		메모리 samsung1tb = new 메모리();
		System.out.println(samsung1tb.getMaxSize()/1024+"GB�Դϴ�.");
		
		samsung1tb.save(500*1024);
		samsung1tb.save(501*1024);
		samsung1tb.load(200*1024);
		samsung1tb.save(501*1024);
	}

}
